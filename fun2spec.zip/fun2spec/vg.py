#!/usr/bin/env python3
"""
Parallel contract checking with unique per-process worker_id in [0, num_parallel_workers).

Usage (via Fire):
    python parallel_check.py --source analysis_code/bde --use_cache True --num_parallel_workers 48 --return_type all --timeout 60
"""

from collections import defaultdict
import fire
import numpy as np
import queue
import common, torch  # noqa: F401  (kept to match your environment/import side effects)
from pathlib import Path
from typing import List, Optional
from time import time, perf_counter, sleep
from common import GeneratorType, SourceType, setup_logging
from code_miner import get_code_miner
from baselines.daikon import DaikonGenerator  # noqa: F401
from function_data import FunctionData
from spec import Postcondition  # noqa: F401
from tester.contract_tester import ContractTester
from tester import get_contract_tester
from llm_generator.fs_generator import FSGenerator  # noqa: F401
import subprocess  # noqa: F401
import logging
import os
import requests  # noqa: F401
from functools import partial  # noqa: F401
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp
import traceback
import json  # noqa: F401
from code_miner.ts_parser import detect_quantifier_implies  # noqa: F401


# ------------------------------- Globals for workers -------------------------------

# These globals are initialized in each worker process by _init_worker()
worker_id = None
ctester_local: Optional[ContractTester] = None


def _init_worker(id_queue,
                 source: str,
                 timeout: int,
                 use_cache: bool,
                 num_parallel_workers: int,
                 source_type: SourceType):
    """
    Per-process initializer. Assigns a unique worker_id and constructs a local ContractTester.
    """
    global worker_id, ctester_local

    try:
        worker_id = id_queue.get(block=True, timeout=10)
    except queue.Empty:
        # Extremely unlikely if max_workers == size of the queue;
        # but we defensively fallback to a sentinel.
        worker_id = -1

    # Build a per-process tester to avoid pickling issues
    ctester_local = get_contract_tester(
        source_type,
        root_dir=source,
        timeout=timeout,
        use_cache=use_cache,
        num_parallel_workers=num_parallel_workers,
    )
    logging.getLogger(__name__).info(f"Initialized worker with worker_id={worker_id}")


def _run_one(function: FunctionData):
    """
    Execute check_on_heap for a single function using the per-process tester and worker_id.
    Returns (runtime_seconds, on_heap_int).
    """
    global worker_id, ctester_local
    t0 = time()
    try:
        on_heap = ctester_local.check_on_heap(function, worker_id)
        rt = time() - t0
        return (rt, int(on_heap))
    except Exception as e:
        # Capture exceptions per task so the whole run doesn't abort.
        logging.getLogger(__name__).error("Error in _run_one:\n%s", traceback.format_exc())
        rt = time() - t0
        return (rt, 0)


# --------------------------------- Main routine -----------------------------------

def run(source: str = "analysis_code/bde",
        use_cache: bool = True,
        num_parallel_workers: int = 48,
        return_type: str = "all",
        timeout: int = 60):
    """
    Orchestrates mining, filtering, and parallel 'on_heap' checking.

    Args:
        source: Path to source repository (root for miner/tester).
        use_cache: Whether to enable caching in miner/tester.
        num_parallel_workers: Number of parallel worker processes. Each has a unique worker_id in [0, N).
        return_type: Return type filter for functions (e.g., 'all', 'bool', etc.).
        timeout: Per-test timeout in seconds.
    """
    setup_logging()
    log = logging.getLogger(__name__)
    log.info("Starting run with source=%s, use_cache=%s, workers=%d, return_type=%s, timeout=%d",
             source, use_cache, num_parallel_workers, return_type, timeout)

    # Determine source type (e.g., BDE, humaneval, mbcpp)
    source_type: SourceType = common.get_source_name(source)

    # Mine repository to extract functions & metadata
    miner = get_code_miner(source=source, use_cache=use_cache)

    # For BDE/humaneval/mbcpp, docstrings exist; filter to those if applicable
    with_docstring = source_type in [SourceType.humaneval, SourceType.BDE, SourceType.mbcpp]

    # Filter functions by return type (and optional docstring requirement)
    filtered_functions: List[FunctionData] = miner.filter_by_return_type(
        return_type=return_type,
        with_docstring=with_docstring
    )

    # Prepare a tester in the main process only if we run sequentially
    ctester = None
    if num_parallel_workers <= 1:
        ctester = get_contract_tester(
            source_type,
            root_dir=source,
            timeout=timeout,
            use_cache=use_cache,
            num_parallel_workers=num_parallel_workers
        )

    # Some sources optionally expose a method to restrict functions to those with test targets
    if ctester is not None and hasattr(ctester, "filter_fns_with_test_target"):
        filtered_functions = ctester.filter_fns_with_test_target(filtered_functions)
    elif ctester is None:
        # If we're going to be parallel but still want to filter by test target,
        # we construct a temporary tester in the main process for this filtering step only.
        tmp_tester = get_contract_tester(
            source_type,
            root_dir=source,
            timeout=timeout,
            use_cache=use_cache,
            num_parallel_workers=num_parallel_workers
        )
        if hasattr(tmp_tester, "filter_fns_with_test_target"):
            filtered_functions = tmp_tester.filter_fns_with_test_target(filtered_functions)
        del tmp_tester

    log.info("Total functions to evaluate: %d", len(filtered_functions))

    runtimes: List[float] = []
    num_on_heap = 0

    if num_parallel_workers <= 1:
        # ---------------------------- Sequential fallback ----------------------------
        log.info("Running sequentially with worker_id=0")
        for function in filtered_functions:
            start_time = time()
            on_heap = ctester.check_on_heap(function, 0)
            runtimes.append(time() - start_time)
            num_on_heap += int(on_heap)

    else:
        # ------------------------------ Parallel branch ------------------------------
        # Create an ID queue so each process gets a unique worker_id
        ctx = mp.get_context("spawn")  # robust across OSes
        id_queue = ctx.Manager().Queue()
        for wid in range(num_parallel_workers):
            id_queue.put(wid)

        with ProcessPoolExecutor(
            max_workers=num_parallel_workers,
            mp_context=ctx,
            initializer=_init_worker,
            initargs=(id_queue, source, timeout, use_cache, num_parallel_workers, source_type),
        ) as ex:
            # chunksize=1 ensures fine-grained load balancing (safer if task runtimes vary)
            for rt, on_heap_int in ex.map(_run_one, filtered_functions, chunksize=1):
                runtimes.append(rt)
                num_on_heap += on_heap_int

    mean_runtime = float(np.mean(runtimes)) if runtimes else 0.0
    print("Mean Runtime ", mean_runtime)
    print("Number instances on heap ", num_on_heap)


if __name__ == "__main__":
    fire.Fire(run)
