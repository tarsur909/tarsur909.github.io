
"""
Given a function, corresponding unit-test and proposed contract. Check if the assertion holds for tests.
"""
import re
import subprocess
import os
import common
from tester.contract_tester import ContractTester
from code_miner.ts_parser import get_all_ts_function_nodes
from typing import Iterator, Optional
from tree_sitter import Node
from common import get_file_lines, get_source_name
from pathlib import Path
from function_data import FunctionData, ReturnType
from concurrent.futures import ProcessPoolExecutor
from functools import partial
import tempfile
import glob
import json


def copy_instance(i, root_dir, timeout):
    bash_command = f"rsync -avc {root_dir}/ analysis_code/tmp/{get_source_name(root_dir)}_{i} --exclude _build/"
    common.run_bash(bash_command, timeout=timeout)


def check_build_instance(i, tmp_dirs):
    """
    Checks if the project builds without errors.
    """
    # Build BDE project and run the test target
    bash_command = f"cd {tmp_dirs[i]} && eval `bbs_build_env -u opt_64_cpp17` && bbs_build configure && bbs_build build --target help"
    output = common.run_bash(bash_command)
    targets = None
    if output is not None and output.returncode == 0:
        raw_output = output.stdout.decode('utf-8')
        # Regular expression to match filenames ending with ".t"
        pattern = r'\b[\w\-\.]+\.t\b'

        # Find all matches
        targets = re.findall(pattern, raw_output)
        targets = [t[:-2] for t in targets] # Remove ".t"
        print('Build tested!')
    else:
        if output is not None:
            print(f"Build failed with Error code {output.returncode}!")
            print(output.returncode)
            print(output.stdout.decode('utf-8'))
            print(output.stderr.decode('utf-8'))
        else:
            print(f"Build failed and the output is None!")
        raise Exception('Build Failed!')
    return targets


class BDETester(ContractTester):
    """
    Given a function in BDE with a corresponding postcondition, this class runs relevant unit tests to
    check if the postcondition holds.
    """
    def __init__(self, root_dir, timeout=30, use_cache=False, num_parallel_workers = None):
        # Copy the contents of repository to a temp path
        _copy_instance = partial(copy_instance, root_dir = root_dir, timeout = timeout)

        with ProcessPoolExecutor(max_workers = num_parallel_workers) as executor:
            results = list(executor.map(_copy_instance, range(num_parallel_workers)))

        super().__init__(root_dir=root_dir, timeout=timeout, use_cache=use_cache, num_parallel_workers = num_parallel_workers)

        fn_heap_cache_path = f"{common.get_project_path()}/data/bde/fn_heap_cache.json"
        self.fn_heap_cache = {}
        if os.path.exists(fn_heap_cache_path):
            if use_cache:
                with open(fn_heap_cache_path, 'r') as f:
                    self.fn_heap_cache = json.load(f)
            else:
                os.remove(fn_heap_cache_path)

    def _check_build(self):
        _check_build_instance = partial(check_build_instance, tmp_dirs = self.tmp_dirs)
        with ProcessPoolExecutor(max_workers = self.num_parallel_workers) as executor:
            all_targets = list(executor.map(_check_build_instance, range(self.num_parallel_workers)))

        assert all(all_targets[i] is not None and set(all_targets[i]) == set(all_targets[0]) for i in range(len(all_targets))), 'Build Failed!'
        self.targets = all_targets[0]



    def check_on_heap(self, fn: FunctionData, worker_id: int) -> bool:
        if fn.function_name in self.fn_heap_cache:
            return self.fn_heap_cache[fn.function_name]

        # Sync sources
        bash_command = f"rsync -av {self.root_dir}/ analysis_code/tmp/{get_source_name(self.root_dir)}_{worker_id} --exclude _build/"
        common.run_bash(bash_command)

        # Map path into tmp tree and extract test target
        path = fn.file_path.replace(self.root_dir, self.tmp_dirs[worker_id])
        test_target = self._extract_target(path)

        # Find build root (directory containing project.cmake)
        build_dir = self.tmp_dirs[worker_id]
        cur_dir = Path(path)
        while cur_dir != '':
            cur_dir = os.path.dirname(cur_dir)
            cmake_file = Path(cur_dir + '/project.cmake')
            if Path(cmake_file).is_file():
                build_dir = cur_dir
                break
        if build_dir is None:
            raise ValueError(f"Path is {path}. Build directory not found!")

        # Full pipeline to run tests (must run inside a bash shell)
        shell_cmd = (
            f'cd "{build_dir}" && '
            f'eval `bbs_build_env -u opt_64_cpp17` && '
            f'bbs_build configure && '
            f'bbs_build build --target "{test_target}" --test run'
        )

        # Unique directory for Massif outputs (avoid stale files)
        massif_dir = tempfile.mkdtemp(prefix=f"massif_{worker_id}_")
        outpat = os.path.join(massif_dir, "massif.%p.out")

        # IMPORTANT: run a *real shell* under Valgrind (no shell=True, no quoting bugs)
        cmd = [
            "valgrind",
            "--tool=massif",
            "--trace-children=yes",
            "--time-unit=B",
            f"--massif-out-file={outpat}",
            "/bin/bash", "-lc", shell_cmd,
        ]

        # Do NOT raise on non-zero exit; tests may fail but we can still parse Massif output
        result = subprocess.run(cmd, text=True, capture_output=True)

        # If needed, you can log result.returncode/result.stderr here for diagnostics
        # print(result.returncode, result.stderr)

        # Inspect only the fresh Massif outputs we just generated
        heap_allocated = False
        for out_file in glob.glob(os.path.join(massif_dir, "massif.*.out")):
            pr = subprocess.run(["ms_print", out_file], text=True, capture_output=True)
            if pr.returncode == 0 and fn.function_name in pr.stdout:
                heap_allocated = True
                break

        self.fn_heap_cache[fn.function_name] = heap_allocated
        return heap_allocated


    def check_assertion(self, fn: FunctionData, assertion: str, worker_id: int, precondition: str = None) -> dict:
        """
        Let's say we want to check that postcondition assertion(1 > 0) holds at the end of the functions when the tests are run.
        If precondition is provided, it will be checked at the beginning of the function.
        The output is written to data/bde/result.jsonl file using `_write_result` function
        """
        cache_key = assertion + (precondition if precondition else "")
        cached_res = self._check_cache(fn.function_string, cache_key)
        if cached_res != None:
            self._write_result(cached_res)
            return cached_res

        # Create a copy of the repository where the original function is replaced with function with an additional assertion
        bash_command = f"rsync -av {self.root_dir}/ analysis_code/tmp/{get_source_name(self.root_dir)}_{worker_id} --exclude _build/"
        common.run_bash(bash_command)
        file_path = fn.file_path.replace(self.root_dir, self.tmp_dirs[worker_id])

        # Repleace the current function content with the addition of this assertion just before any return statement
        file_lines = get_file_lines(fn.file_path)

        # Start with original file content
        all_functions = get_all_ts_function_nodes(fn.file_path)

        # Create an empty file to write the results for CPP execution
        open(self._tmp_result_files[worker_id], 'w+').close()

        # Find the function node in the tree-sitter AST that matches the offset of the function in the file
        function_node = next(filter(lambda fn_node: fn_node.start_byte == fn.offset, all_functions), None)

        if function_node == None:
            return

        new_file_content = self._add_return_stub(assertion, file_lines, function_node, return_type=fn.return_type, worker_id = worker_id, precondition=precondition)

        # replce the file_content with new_file_content
        print(f"Rewriting the function {fn.function_name} in temporary file {file_path}")
        # Add header for writing to a file
        self._add_fstream_header(file_path, new_file_content)

        # Run unit test for the target file
        try:
            output = self._run_ut(file_path, worker_id)
        except Exception as e:
            print(f"Exception while running unit test for {file_path}: " + str(e))
            output = None
        if output != None:
            output_txt = output.stdout.decode('utf-8') + "\n" + output.stderr.decode('utf-8')
        else:
            output_txt = ""

        if output is not None and output.returncode == 0:
            print('Test executed!')
        else:
            if output is not None:
                print(f"Test execution failed with Error code {output.returncode}!")
                print(output.returncode)
                print(output_txt)
            else:
                print(f"Test failed and the output is None!")

        # Aggregate the results from tmp file and store it in a `jsonl` with following format:
        return_code = output.returncode if output is not None else 1
        result = self._aggregate_results(fn, assertion, return_code, output_txt, worker_id)
        return result


    def _add_fstream_header(self, file_path, new_file_content):
        new_file_content = f'#include "{os.path.abspath(self.root_dir)}/groups/bsl/bsl+bslhdrs/bsl_fstream.h"\n#include "{os.path.abspath(self.root_dir)}/groups/bsl/bsls/bsls_assert.h"\n#include "{self.sep_conj_file}"\n' + new_file_content
        with open(file_path, "w") as f:
            f.write(new_file_content)

    def _add_return_stub(self, assertion: str, file_lines: Iterator[str], function_node: Node, return_type: ReturnType = None, worker_id=None, precondition: str = None):
        """
        Given file content split into lines `file_lines` and a tree-sitter function node, find and replace all occurences
        of return statements with a corresponding print stub.

        Additionally, for each named input parameter of the function, insert `auto old_<name> = <name>;` at the
        beginning of the function body.
        
        If precondition is provided, also insert an assertion check for the precondition at the beginning of the function body.
        """
        import re

        # ---- Helpers (Tree-sitter traversal) ------------------------------------
        def _first_descendant(node: Node, target_type: str) -> Node | None:
            stack = [node]
            while stack:
                n = stack.pop()
                if getattr(n, "type", None) == target_type:
                    return n
                stack.extend(getattr(n, "children", []))
            return None

        def _descendants_matching(node: Node, predicate) -> list[Node]:
            out = []
            stack = [node]
            while stack:
                n = stack.pop()
                try:
                    if predicate(n):
                        out.append(n)
                    stack.extend(getattr(n, "children", []))
                except Exception:
                    # Be robust against unexpected node shapes
                    pass
            return out

        # ---- Extract parameter names & locate function body ---------------------
        param_names: list[str] = []
        param_list = _first_descendant(function_node, "parameter_list")
        if param_list is not None:
            # Collect parameter_declaration nodes (sometimes they can be nested)
            params = [c for c in param_list.children if getattr(c, "type", "") == "parameter_declaration"]
            if not params:
                params = _descendants_matching(param_list, lambda nn: getattr(nn, "type", "") == "parameter_declaration")

            for p in params:
                # Find identifiers that belong to a *declarator* subtree inside this parameter (i.e., the variable name)
                id_nodes: list[Node] = []
                stack = [p]
                while stack:
                    n = stack.pop()
                    if getattr(n, "type", None) == "identifier":
                        # Check that this identifier sits under some *declarator* node (and not as part of a type)
                        in_declarator = False
                        anc = n
                        # Walk ancestors up to 'p' to see if any ancestor is a declarator-like node
                        try:
                            while anc is not None and anc is not p:
                                if "declarator" in getattr(anc, "type", ""):
                                    in_declarator = True
                                    break
                                anc = getattr(anc, "parent", None)
                        except Exception:
                            # If parent links aren't available, accept it; Tree-sitter Python bindings usually provide them.
                            in_declarator = True
                        if in_declarator:
                            id_nodes.append(n)
                    stack.extend(getattr(n, "children", []))

                if id_nodes:
                    # Pick the rightmost identifier by byte position (most specific variable name)
                    id_nodes.sort(key=lambda x: x.start_byte)
                    name = id_nodes[-1].text.decode("utf-8")
                    if name:
                        param_names.append(name)

            # De-duplicate while preserving order
            seen = set()
            param_names = [n for n in param_names if not (n in seen or seen.add(n))]

        body_node = _first_descendant(function_node, "compound_statement")

        # ---- Existing return-stub transformation --------------------------------
        worklist: list[Node] = list(function_node.children)  # ensure it's mutable
        new_file_content = ''.join(file_lines)  # Start with original file content

        # Do a BFS of the AST and find the return nodes
        while len(worklist) > 0:
            cur_node = worklist.pop()

            if getattr(cur_node, "type", None) == 'return_statement':

                # children are 1. "return" 2. expression 3. semicolon
                if len(cur_node.children) != 3:
                    print(f"Unexpected code at the return: {cur_node.text}")
                    continue

                start_line = cur_node.start_point.row
                end_line = cur_node.end_point.row

                file_lines = new_file_content.splitlines(keepends=True)  # keep lines in sync
                original_context = ''.join(file_lines[start_line:end_line + 1])

                return_str = cur_node.text.decode('utf-8')

                # Create the stub to replace the return statement
                # The stub does following operations in the C++ code
                # 1) Creates a temporary variable `res_tmp` and assigns it the return expression
                # 2) Prints function name, assertion validity
                # 3) Returns `res_tmp`
                return_expr = cur_node.children[1]
                return_expr_str = return_expr.text.decode('utf-8')

                tmp_var_string = self._get_res_tmp_assignment(return_type, return_expr_str)

                create_file = f"std::ofstream f; f.open(std::string(\"{self._tmp_result_files[worker_id]}\"), std::ios::app); "

                new_code_stub = (
                    tmp_var_string
                    + create_file
                    + f"f << __FUNCTION__ << \" \" << ({assertion}) << \"\\n\"; "
                    f"f.close(); BSLS_ASSERT({assertion}); return res_tmp;"
                )

                # Replace the exact return statement with our stub (no newlines added)
                new_context = original_context.replace(return_str, new_code_stub)

                new_file_content = ''.join(file_lines[:start_line] + [new_context] + file_lines[end_line + 1:])
                # file_lines is re-derived at the top of the loop to keep positions coherent
            else:
                # Continue BFS
                worklist += list(getattr(cur_node, "children", []))

        # ---- Insert `auto old_<param> = <param>;` and precondition at the start of the body -------
        if body_node is not None and (param_names or precondition):
            # Work from the *latest* content after return replacements
            file_lines = new_file_content.splitlines(keepends=True)

            open_line_idx = body_node.start_point.row  # line containing '{'
            if 0 <= open_line_idx < len(file_lines):
                open_line = file_lines[open_line_idx]

                # Detect indentation on the '{' line; add one more level inside the body
                ws_match = re.match(r'[ \t]*', open_line)
                base_indent = ws_match.group(0) if ws_match else ''
                # Use a tab if tabs are present, otherwise 4 spaces
                unit_indent = '\t' if '\t' in base_indent else '    '
                body_indent = base_indent + unit_indent

                # Build the inserted block
                insertion_block = ''
                
                # Add old_<param> assignments
                if param_names:
                    insertion_block += ''.join(f"{body_indent}auto old_{name} = {name};\n" for name in param_names)
                
                # Add precondition assertion
                if precondition:
                    insertion_block += f"{body_indent}BSLS_ASSERT({precondition});\n"

                # Put the block immediately after the opening '{'
                brace_idx = open_line.find('{')

                if brace_idx == -1:
                    # Fallback: we didn't find the brace on this line—insert on the following line.
                    new_file_content = ''.join(
                        file_lines[:open_line_idx + 1] + [insertion_block] + file_lines[open_line_idx + 1:]
                    )
                else:
                    # Preserve original line ending
                    if open_line.endswith('\r\n'):
                        eol = '\r\n'
                        line_core = open_line[:-2]
                    elif open_line.endswith('\n'):
                        eol = '\n'
                        line_core = open_line[:-1]
                    else:
                        eol = ''
                        line_core = open_line

                    before = line_core[:brace_idx + 1]
                    after = line_core[brace_idx + 1:]

                    if after.strip() == '':
                        # Nothing significant after '{' on this line—keep it as-is and insert on the next line
                        new_lines = [before + eol, insertion_block]
                        new_file_content = ''.join(
                            file_lines[:open_line_idx] + new_lines + file_lines[open_line_idx + 1:]
                        )
                    else:
                        # There is code after '{' on the same line. Split it so our insertion comes first.
                        # Reindent the "after" content onto its own line.
                        new_open = before + eol
                        new_after = f"{body_indent}{after.lstrip()}{eol}"
                        new_lines = [new_open, insertion_block, new_after]
                        new_file_content = ''.join(
                            file_lines[:open_line_idx] + new_lines + file_lines[open_line_idx + 1:]
                        )

        return new_file_content



    def _run_ut(self, path: str, worker_id: int) -> Optional[subprocess.Popen]:
        """
        Run unit test provided the path of the file to be tested or the test file itself. Given a file with path file.cpp,
        this function looks for the file file.t.cpp in same directory.
        """
        # Extract target from the path
        test_target = self._extract_target(path)

        # Find root of the target
        build_dir = self.tmp_dirs[worker_id]
        cur_dir = Path(path)
        while cur_dir != '':
            cur_dir = os.path.dirname(cur_dir)
            cmake_file = Path(cur_dir + '/project.cmake')
            if cmake_file.is_file():
                build_dir = cur_dir
                break
        if build_dir == None:
            raise ValueError(f"Path is {path}. Build directory not found!")

        # Change directory to the target directory
        # Build BDE project and run the test target
        bash_command = f"cd {build_dir} && eval `bbs_build_env -u opt_64_cpp17` && bbs_build configure && bbs_build build --target {test_target} --test run"
        print(bash_command)
        return common.run_bash(bash_command)

    def _extract_target(self, path):
        if path.endswith('.t.cpp'):
            target = path.split('/')[-1][-5]
        elif path.endswith('.cpp'):
            target = path.split('/')[-1][:-4]
        else:
            raise ValueError('Unknown target!')
        return target

    def filter_fns_with_test_target(self, fns) -> Iterator[FunctionData]:
        filtered_fns = [fn for fn in fns if self._extract_target(fn.file_path) in self.targets]
        return filtered_fns
