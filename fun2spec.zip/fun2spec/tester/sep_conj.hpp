// ==========================================================================
//  object_graph_simple.hpp  –  tiny, header-only heap-address enumerator
//                         compatible with C++17 and later
// --------------------------------------------------------------------------
//  MIT licence • 2025
// ==========================================================================
#pragma once

#include <array>
#include <cassert>
#include <cstddef>
#include <deque>
#include <forward_list>
#include <list>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <variant>
#include <vector>
#include <iterator>    // for std::begin / std::end
#include <algorithm>   // for std::apply (via <tuple>)

namespace og {

// ──────────────────────────────────────────────────────────────────────────
//  void_t for C++17
// ──────────────────────────────────────────────────────────────────────────
template<typename...> using void_t = void;

// ──────────────────────────────────────────────────────────────────────────
//  Trait: pointer-like?
// ──────────────────────────────────────────────────────────────────────────
template<class T> constexpr bool is_raw_ptr_v   = std::is_pointer<T>::value;

template<class T> struct is_unique_ptr      : std::false_type {};
template<class U, class D>
struct is_unique_ptr<std::unique_ptr<U,D>>  : std::true_type {};
template<class T> constexpr bool is_unique_ptr_v = is_unique_ptr<T>::value;

template<class T> struct is_shared_ptr      : std::false_type {};
template<class U>
struct is_shared_ptr<std::shared_ptr<U>>   : std::true_type {};
template<class T> constexpr bool is_shared_ptr_v = is_shared_ptr<T>::value;

template<class T>
constexpr bool is_pointer_like_v =
    is_raw_ptr_v<T> || is_unique_ptr_v<T> || is_shared_ptr_v<T>;

// ──────────────────────────────────────────────────────────────────────────
//  Trait: std::optional?
// ──────────────────────────────────────────────────────────────────────────
template<class, class=void> struct is_optional : std::false_type {};
template<class U>
struct is_optional<std::optional<U>, void_t<typename std::optional<U>::value_type>> 
    : std::true_type {};
template<class T> constexpr bool is_optional_v = is_optional<std::decay_t<T>>::value;

// ──────────────────────────────────────────────────────────────────────────
//  Trait: std::variant?
// ──────────────────────────────────────────────────────────────────────────
template<class, class=void> struct is_variant : std::false_type {};
template<class... Ts>
struct is_variant<std::variant<Ts...>, void_t<std::variant<Ts...>>> 
    : std::true_type {};
template<class T> constexpr bool is_variant_v = is_variant<std::decay_t<T>>::value;

// ──────────────────────────────────────────────────────────────────────────
//  Trait: string leaf?
// ──────────────────────────────────────────────────────────────────────────
template<class T>
constexpr bool is_string_v = std::is_same<
    typename std::decay<T>::type,
    std::string>::value;

// ──────────────────────────────────────────────────────────────────────────
//  Trait: iterable? (has std::begin/end) but not string
// ──────────────────────────────────────────────────────────────────────────
template<class, class=void> struct is_iterable : std::false_type {};
template<class T>
struct is_iterable<
    T,
    void_t<
      decltype(std::begin(std::declval<T>())),
      decltype(std::end  (std::declval<T>()))
    >
> : std::true_type {};
template<class T>
constexpr bool is_iterable_v =
    is_iterable<T>::value && !is_string_v<T>;

// ──────────────────────────────────────────────────────────────────────────
//  Trait: tuple-like? (has std::tuple_size) but not pointer/string
// ──────────────────────────────────────────────────────────────────────────
template<class, class=void> struct is_tuple_like : std::false_type {};
template<class T>
struct is_tuple_like<
    T,
    void_t<typename std::tuple_size<T>::type>
> : std::true_type {};
template<class T>
constexpr bool is_tuple_like_v =
    is_tuple_like<std::decay_t<T>>::value && !is_pointer_like_v<T> && !is_string_v<T>;

// ──────────────────────────────────────────────────────────────────────────
//  Trait: user-provided visit_references?
// ──────────────────────────────────────────────────────────────────────────
template<class, class=void> struct has_visit_references : std::false_type {};
template<class T>
struct has_visit_references<
    T,
    void_t< decltype(
      visit_references( std::declval<const T&>(),
                        std::declval<std::unordered_set<const void*>&>(),
                        std::declval<std::unordered_set<const void*>&>() )
    )>
> : std::true_type {};
template<class T>
constexpr bool has_visit_references_v = has_visit_references<T>::value;

// ──────────────────────────────────────────────────────────────────────────
//  Extract raw address from pointer-like
// ──────────────────────────────────────────────────────────────────────────
template<class Ptr>
const void* ptr_addr(const Ptr& p) {
    if constexpr (is_raw_ptr_v<Ptr>)
        return static_cast<const void*>(p);
    else if constexpr (is_unique_ptr_v<Ptr> || is_shared_ptr_v<Ptr>)
        return static_cast<const void*>(p.get());
    else
        return nullptr;
}

// ──────────────────────────────────────────────────────────────────────────
//  Core traversal: one `if constexpr` chain
// ──────────────────────────────────────────────────────────────────────────
template<class T>
void traverse(const T& obj,
              std::unordered_set<const void*>& out,
              std::unordered_set<const void*>& seen)
{
    if constexpr (is_pointer_like_v<T>) {
        if (!obj) return;
        const void* a = ptr_addr(obj);
        if (!seen.insert(a).second) return;
        out.insert(a);
        traverse(*obj, out, seen);

    } else if constexpr (is_optional_v<T>) {
        if (obj) traverse(*obj, out, seen);

    } else if constexpr (is_variant_v<T>) {
        std::visit([&](auto const& alt){ traverse(alt, out, seen); }, obj);

    } else if constexpr (is_string_v<T>
                      || std::is_arithmetic<T>::value
                      || std::is_enum<T>::value) {
        /* leaf – nothing */

    } else if constexpr (is_iterable_v<T>) {
        for (auto const& e : obj)
            traverse(e, out, seen);

    } else if constexpr (is_tuple_like_v<T>) {
        std::apply([&](auto const&... elems){
            (traverse(elems, out, seen), ...);
        }, obj);

    } else if constexpr (has_visit_references_v<T>) {
        visit_references(obj, out, seen);

    } else {
        // nothing else we know how to traverse
    }
}

// ──────────────────────────────────────────────────────────────────────────
//  Public API
// ──────────────────────────────────────────────────────────────────────────
template<class Root>
std::unordered_set<const void*> collect_heap_addresses(const Root& root)
{
    std::unordered_set<const void*> result, seen;
    traverse(root, result, seen);
    return result;
}

// ──────────────────────────────────────────────────────────────────────────
//  Hook macro for user aggregates
// ──────────────────────────────────────────────────────────────────────────
#define MAKE_VISITABLE(Type, ...)                                      \
inline void visit_references(const Type& self,                         \
                             std::unordered_set<const void*>& out,     \
                             std::unordered_set<const void*>& seen)    \
{                                                                      \
    using og::traverse;                                                \
    /* pack members into tuple, then apply traverse */                 \
    std::apply([&](auto&&... members){                                 \
        (traverse(members, out, seen), ...);                           \
    }, std::forward_as_tuple(__VA_ARGS__));                            \
}

} // namespace og
