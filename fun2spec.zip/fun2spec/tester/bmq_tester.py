
import subprocess
import common
from tester.contract_tester import ContractTester
from code_miner.ts_parser import get_all_ts_function_nodes
from typing import Iterator, Optional
from tree_sitter import Node
from common import get_file_lines, get_source_name
from pathlib import Path
from function_data import FunctionData, ReturnType
from concurrent.futures import ProcessPoolExecutor
from functools import partial
import os
import re
import tempfile
import glob
import json


os.environ['CURL_CA_BUNDLE'] = 'CABundle.pem'
os.environ['REQUESTS_CA_BUNDLE'] = 'CABundle.pem'


def copy_instance(i, root_dir, timeout):
    bash_command = f"rsync -avc {root_dir}/ analysis_code/tmp/{get_source_name(root_dir)}_{i} --exclude build/blazingmq"
    common.run_bash(bash_command, timeout=timeout)

def check_build_instance(i, tmp_dirs):
    """
    Checks if the project builds without errors.
    """
    # Build BMQ project
    bash_command = f"cd {tmp_dirs[i]} && bin/build-ubuntu.sh && cmake --build build/blazingmq --parallel 32 --target all.t"
    output = common.run_bash(bash_command, timeout=800)


    if output is not None and output.returncode == 0:
        print('Build tested!')
    else:
        if output is not None:
            print(f"Build failed with Error code {output.returncode}!")
            print(output.returncode)
            print(output.stdout.decode('utf-8'))
            print(output.stderr.decode('utf-8'))
        else:
            print(f"Build failed and the output is None!")
        raise Exception('Build Failed!')


class BMQTester(ContractTester):
    """
    Given a function in BlazingMQ with a corresponding postcondition, this class runs relevant unit tests to
    check if the postcondition holds.
    """
    def __init__(self, root_dir, timeout=30, use_cache=True, num_parallel_workers = None):
        # Copy the contents of repository to a temp path
        _copy_instance = partial(copy_instance, root_dir = root_dir, timeout = timeout)

        with ProcessPoolExecutor(max_workers = num_parallel_workers) as executor:
            results = list(executor.map(_copy_instance, range(num_parallel_workers)))

        super().__init__(root_dir=root_dir, timeout=timeout, use_cache=use_cache, num_parallel_workers = num_parallel_workers)

        # ---- NEW: heap cache like BDETester ------------------------------------
        fn_heap_cache_path = f"{common.get_project_path()}/data/bmq/fn_heap_cache.json"
        self.fn_heap_cache = {}
        if os.path.exists(fn_heap_cache_path):
            if use_cache:
                with open(fn_heap_cache_path, 'r') as f:
                    try:
                        self.fn_heap_cache = json.load(f)
                    except Exception:
                        self.fn_heap_cache = {}
            else:
                os.remove(fn_heap_cache_path)
        self._fn_heap_cache_path = fn_heap_cache_path

    def _check_build(self):
        """
        Checks if the project builds without errors.
        """
        _check_build_instance = partial(check_build_instance, tmp_dirs = self.tmp_dirs)
        with ProcessPoolExecutor(max_workers = self.num_parallel_workers) as executor:
            all_targets = list(executor.map(_check_build_instance, range(self.num_parallel_workers)))


    def check_on_heap(self, fn: FunctionData, worker_id: int) -> bool:
        """
        Run the unit tests for the file containing `fn` under Valgrind Massif and parse
        the Massif output to determine whether `fn.function_name` appears in heap
        allocation call stacks. Caches by function name (like BDETester).
        """
        # Use cache if present
        if fn.function_name in self.fn_heap_cache:
            return self.fn_heap_cache[fn.function_name]

        # Sync sources into this worker's tmp dir (exclude the build to keep things clean)
        bash_command = (
            f"rsync -av {self.root_dir}/ analysis_code/tmp/{get_source_name(self.root_dir)}_{worker_id} "
            f"--exclude build/blazingmq"
        )
        common.run_bash(bash_command)

        # Map the function's path into the tmp tree
        path = fn.file_path.replace(self.root_dir, self.tmp_dirs[worker_id])

        # Derive the test regex for ctest (same approach as _run_ut)
        test_regex = os.path.basename(path)[:-4]  # strip ".cpp"

        # Build root for BMQ: run build script & ctest in the repo root (tmp dir)
        build_dir = self.tmp_dirs[worker_id]

        # Full pipeline under a real shell (so env, && chaining, etc. work)
        shell_cmd = (
            f'cd "{build_dir}" && '
            f'bin/build-ubuntu.sh && '
            f'cmake --build build/blazingmq --parallel 32 --target all.t && '
            f'cd build/blazingmq && '
            f'ctest -R "{test_regex}"'
        )

        # Unique directory to gather fresh Massif outputs
        massif_dir = tempfile.mkdtemp(prefix=f"massif_{worker_id}_")
        outpat = os.path.join(massif_dir, "massif.%p.out")

        # Run under Valgrind Massif; do not raise on non-zero exit (tests may fail
        # yet Massif output could still be present/parseable)
        cmd = [
            "valgrind",
            "--tool=massif",
            "--trace-children=yes",
            "--time-unit=B",
            f"--massif-out-file={outpat}",
            "/bin/bash", "-lc", shell_cmd,
        ]

        result = subprocess.run(cmd, text=True, capture_output=True)

        # Parse Massif outputs we just generated
        heap_allocated = False
        for out_file in glob.glob(os.path.join(massif_dir, "massif.*.out")):
            pr = subprocess.run(["ms_print", out_file], text=True, capture_output=True)
            if pr.returncode == 0 and fn.function_name in pr.stdout:
                heap_allocated = True
                break

        # Cache and return
        self.fn_heap_cache[fn.function_name] = heap_allocated
        return heap_allocated


    def check_assertion(self, fn: FunctionData, assertion: str, worker_id: int, precondition: str = None):
        """
        Checks if the `assertion` holds at the end of the function execution.
        If precondition is provided, it will be checked at the beginning of the function.
        The output is written to data/bmq/result.csv file using `_write_result` function
        """
        # cached_res = self._check_cache(fn.function_string, assertion)
        # if cached_res != None:
        #     self._write_result(cached_res)
        #     return cached_res

        # Create a copy of the repository where the original function is replaced with function with an additional assertion
        bash_command = f"rsync -av {self.root_dir}/ analysis_code/tmp/{get_source_name(self.root_dir)}_{worker_id} --exclude build/blazingmq"
        common.run_bash(bash_command)
        file_path = fn.file_path.replace(self.root_dir, self.tmp_dirs[worker_id])

        # Repleace the current function content with the addition of this assertion just before any return statement
        file_lines = get_file_lines(fn.file_path)

        # Start with original file content
        new_file_content = ''.join(file_lines)
        all_functions = get_all_ts_function_nodes(fn.file_path)

        # Create an empty file to write the results for CPP execution
        open(self._tmp_result_files[worker_id], 'w+').close()

        # Find the function node in the tree-sitter AST that matches the offset of the function in the file
        function_node = next(filter(lambda fn_node: fn_node.start_byte == fn.offset, all_functions), None)

        if function_node == None:
            return

        new_file_content = self._add_return_stub(assertion, file_lines, function_node, fn.return_type, worker_id, precondition=precondition)

        # replce the file_content with new_file_content
        print(f"Rewriting the function {fn.function_name} in temporary file {file_path}")
        # Add header for writing to a file
        self._add_fstream_header(file_path, new_file_content)

        # Run unit test for the target file
        output = self._run_ut(file_path, worker_id)
        if output != None:
            output_txt = output.stdout.decode('utf-8') + "\n" + output.stderr.decode('utf-8')
        else:
            output_txt = ""

        if output is not None and output.returncode == 0:
            print('Test executed!')
        else:
            if output is not None:
                print(f"Test execution failed with Error code {output.returncode}!")
                print(output.returncode)
                print(output_txt)
            else:
                print(f"Test failed and the output is None!")

        # Aggregate the results from tmp file and store it in a jsonl with following format:
        return_code = output.returncode if output is not None else 1
        result = self._aggregate_results(fn, assertion, return_code, output_txt, worker_id)
        return result

    def _run_ut(self, path: str, worker_id: int) -> Optional[subprocess.Popen]:
        """
        Run unit test provided the path of the file to be tested or the test file itself. Given a file with path file.cpp,
        this function looks for the file file.t.cpp in same directory.
        """
        # Change location to BMQ build directory
        build_dir = "build/blazingmq"

        # Run ctest with -R
        test_file = path.split('/')[-1][:-4]
        return common.run_bash(f"cd {self.tmp_dirs[worker_id]} && bin/build-ubuntu.sh && cmake --build build/blazingmq --parallel 32 --target all.t && cd {build_dir} && ctest -R {test_file}", timeout=800)



    def _add_fstream_header(self, file_path, new_file_content):
        new_file_content = f'#include <bsl_fstream.h>\n#include "{self.sep_conj_file}"\n' + new_file_content
        with open(file_path, "w") as f:
            f.write(new_file_content)

    def _add_return_stub(
        self,
        assertion: str,
        file_lines: Iterator[str],
        function_node: Node,
        return_type: ReturnType = None,
        worker_id: int = None,
        precondition: str = None
    ) -> str:
        """
        Enhanced version (like BDETester):
        - Rewrites every `return` to:
            * capture the expression into `res_tmp` (type-safe via `_get_res_tmp_assignment`),
            * append "<function_name> <assertion_truth>\n" to the tmp results file,
            * assert and return `res_tmp`.
        - Inserts `auto old_<param> = <param>;` immediately after the opening '{' of the function
        body, with proper indentation.
        - If precondition is provided, also inserts an assertion check for the precondition at the beginning of the function body.
        """
        # ---- Helpers (Tree-sitter traversal) ------------------------------------
        def _first_descendant(node: Node, target_type: str) -> Optional[Node]:
            stack = [node]
            while stack:
                n = stack.pop()
                if getattr(n, "type", None) == target_type:
                    return n
                stack.extend(getattr(n, "children", []))
            return None

        def _descendants_matching(node: Node, predicate) -> list[Node]:
            out = []
            stack = [node]
            while stack:
                n = stack.pop()
                try:
                    if predicate(n):
                        out.append(n)
                    stack.extend(getattr(n, "children", []))
                except Exception:
                    pass
            return out

        # ---- Extract parameter names -------------------------------------------
        param_names: list[str] = []
        param_list = _first_descendant(function_node, "parameter_list")
        if param_list is not None:
            # Collect parameter_declaration nodes (sometimes nested)
            params = [c for c in param_list.children if getattr(c, "type", "") == "parameter_declaration"]
            if not params:
                params = _descendants_matching(param_list, lambda nn: getattr(nn, "type", "") == "parameter_declaration")

            for p in params:
                # Find identifiers that belong to a declarator subtree (i.e., variable name)
                id_nodes: list[Node] = []
                stack = [p]
                while stack:
                    n = stack.pop()
                    if getattr(n, "type", None) == "identifier":
                        in_declarator = False
                        anc = n
                        try:
                            while anc is not None and anc is not p:
                                if "declarator" in getattr(anc, "type", ""):
                                    in_declarator = True
                                    break
                                anc = getattr(anc, "parent", None)
                        except Exception:
                            # Be permissive if parent links are absent
                            in_declarator = True
                        if in_declarator:
                            id_nodes.append(n)
                    stack.extend(getattr(n, "children", []))

                if id_nodes:
                    id_nodes.sort(key=lambda x: x.start_byte)
                    name = id_nodes[-1].text.decode("utf-8")
                    if name:
                        param_names.append(name)

            # De-duplicate while preserving order
            seen = set()
            param_names = [n for n in param_names if not (n in seen or seen.add(n))]

        body_node = _first_descendant(function_node, "compound_statement")

        # ---- Rewrite returns -----------------------------------------------------
        worklist: list[Node] = list(function_node.children)
        new_file_content = ''.join(file_lines)  # mutable working copy

        while worklist:
            cur_node = worklist.pop()

            if getattr(cur_node, "type", None) == 'return_statement':
                # children are: 1) 'return' 2) expression 3) ';'
                if len(getattr(cur_node, "children", [])) != 3:
                    # Be robust: skip unexpected shapes
                    continue

                start_line = cur_node.start_point.row
                end_line = cur_node.end_point.row

                # Re-slice from the current working copy to keep positions coherent
                file_lines = new_file_content.splitlines(keepends=True)
                original_context = ''.join(file_lines[start_line:end_line + 1])

                return_str = cur_node.text.decode('utf-8')
                return_expr = cur_node.children[1]
                return_expr_str = return_expr.text.decode('utf-8')

                # Get `auto res_tmp = <expr>;` (or typed equivalent) via helper
                tmp_var_string = self._get_res_tmp_assignment(return_type, return_expr_str)

                # Append to temporary results (same path as used elsewhere)
                create_file = (
                    f"std::ofstream f; "
                    f"f.open(std::string(\"{self._tmp_result_files[worker_id]}\"), std::ios::app); "
                )

                new_code_stub = (
                    tmp_var_string
                    + create_file
                    + f"f << __FUNCTION__ << \" \" << ({assertion}) << \"\\n\"; "
                    + "f.close(); "
                    + f"BSLS_ASSERT({assertion}); "
                    + "return res_tmp;"
                )

                # Replace the original `return ...;` with our stub (no added newlines)
                new_context = original_context.replace(return_str, new_code_stub)
                new_file_content = ''.join(
                    file_lines[:start_line] + [new_context] + file_lines[end_line + 1:]
                )
            else:
                worklist += list(getattr(cur_node, "children", []))

        # ---- Insert `auto old_<param> = <param>;` and precondition at the beginning of the body ----
        if body_node is not None and (param_names or precondition):
            file_lines = new_file_content.splitlines(keepends=True)
            open_line_idx = body_node.start_point.row  # line containing '{'
            if 0 <= open_line_idx < len(file_lines):
                open_line = file_lines[open_line_idx]

                # Determine indentation level inside the body
                ws_match = re.match(r'[ \t]*', open_line)
                base_indent = ws_match.group(0) if ws_match else ''
                unit_indent = '\t' if '\t' in base_indent else '    '
                body_indent = base_indent + unit_indent

                # Build the inserted block
                insertion_block = ''
                
                # Add old_<param> assignments
                if param_names:
                    insertion_block += ''.join(
                        f"{body_indent}auto old_{name} = {name};\n" for name in param_names
                    )
                
                # Add precondition assertion
                if precondition:
                    insertion_block += f"{body_indent}BSLS_ASSERT({precondition});\n"

                brace_idx = open_line.find('{')
                if brace_idx == -1:
                    # No brace on this line: insert on next line
                    new_file_content = ''.join(
                        file_lines[:open_line_idx + 1] + [insertion_block] + file_lines[open_line_idx + 1:]
                    )
                else:
                    # Preserve original line ending
                    if open_line.endswith('\r\n'):
                        eol = '\r\n'
                        line_core = open_line[:-2]
                    elif open_line.endswith('\n'):
                        eol = '\n'
                        line_core = open_line[:-1]
                    else:
                        eol = ''
                        line_core = open_line

                    before = line_core[:brace_idx + 1]
                    after = line_core[brace_idx + 1:]

                    if after.strip() == '':
                        # Nothing after '{' -> insert on the next line
                        new_lines = [before + eol, insertion_block]
                        new_file_content = ''.join(
                            file_lines[:open_line_idx] + new_lines + file_lines[open_line_idx + 1:]
                        )
                    else:
                        # Code on same line as '{' -> split it and keep order
                        new_open = before + eol
                        new_after = f"{body_indent}{after.lstrip()}{eol}"
                        new_lines = [new_open, insertion_block, new_after]
                        new_file_content = ''.join(
                            file_lines[:open_line_idx] + new_lines + file_lines[open_line_idx + 1:]
                        )

        return new_file_content

