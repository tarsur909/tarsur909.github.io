#pragma once

#include <type_traits>
#include <initializer_list>
#include <unordered_set>
#include <utility>
#include <cstddef>
#include <cstdint>

template <class T>
inline const void* __sl_addr_of(T* p) { return static_cast<const void*>(p); }
template <class T>
inline const void* __sl_addr_of(T& r) { return static_cast<const void*>(&r); }

inline bool __sl_all_distinct(std::initializer_list<const void*> cells) {
    std::unordered_set<const void*> seen;
    for (auto p : cells) { if (p == nullptr) return false; if (!seen.insert(p).second) return false; }
    return true;
}

// ===============================
// Null-safe equality / inequality
// ===============================
template <class L, class R>
inline bool __sl_eq(L&& l, R&& r) {
    using Ld = std::decay_t<L>;
    using Rd = std::decay_t<R>;
    // pointer vs integer
    if constexpr (std::is_pointer_v<Ld> && std::is_integral_v<Rd>) {
        return r == 0 ? (l == nullptr) : false;
    } else if constexpr (std::is_integral_v<Ld> && std::is_pointer_v<Rd>) {
        return l == 0 ? (nullptr == r) : false;
    // nullptr_t vs pointer/integer
    } else if constexpr (std::is_same_v<Ld, std::nullptr_t>) {
        if constexpr (std::is_pointer_v<Rd>)  return r == nullptr;
        if constexpr (std::is_integral_v<Rd>) return r == 0;
        else                                   return false;
    } else if constexpr (std::is_same_v<Rd, std::nullptr_t>) {
        if constexpr (std::is_pointer_v<Ld>)  return l == nullptr;
        if constexpr (std::is_integral_v<Ld>) return l == 0;
        else                                   return false;
    // otherwise: defer to native ==
    } else {
        return l == r;
    }
}

template <class L, class R>
inline bool __sl_ne(L&& l, R&& r) {
    return !__sl_eq(std::forward<L>(l), std::forward<R>(r));
}

// ===============================
// Points-to
// ===============================
template <class L, class R>
inline bool __sl_mapsto(L&& loc, R&& rhs) {
    using T = std::decay_t<L>;
    if constexpr (std::is_pointer_v<T>) {
        if (loc == nullptr) return false;
        using P = std::remove_pointer_t<T>;
        if constexpr (std::is_pointer_v<P>) {
            using Rdec = std::decay_t<R>;
            if constexpr (std::is_same_v<Rdec, std::nullptr_t>) return (*loc == nullptr);
            else if constexpr (std::is_pointer_v<Rdec>)         return (*loc == rhs);
            else if constexpr (std::is_integral_v<Rdec>)        return (rhs == 0) && (*loc == nullptr);
            else                                                return false;
        } else {
            // loc is pointer to a non-pointer cell (e.g., int*, std::string*, Node*)
            using Rdec = std::decay_t<R>;
            // If RHS is a pointer to the same pointee type P, interpret as address equality:
            //   T* loc; T* rhs;  loc ↦ rhs   ≡   (loc == rhs)
            if constexpr (std::is_pointer_v<Rdec> &&
                            std::is_same_v<std::remove_pointer_t<Rdec>, P>) {
                return (loc == rhs);
            } else {
                return (*loc == rhs);
            }
        }
    } else {
        return (loc == rhs);
    }
}

template <class L>
inline bool __sl_mapsto_any(L&& loc) {
    using T = std::decay_t<L>;
    if constexpr (std::is_pointer_v<T>) return loc != nullptr;
    else                                return true;
}

// ===============================
// Recursion helper for PRED lambdas
// ===============================
template <class F>
struct __sl_rec {
    F f;
    template <class... Args>
    bool operator()(Args&&... args) const {
        return f(*this, std::forward<Args>(args)...);
    }
};
template <class F>
inline __sl_rec<F> __sl_make_rec(F f) { return __sl_rec<F>{std::move(f)}; }
