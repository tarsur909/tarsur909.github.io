
import re
from function_data import FunctionData
from tester.contract_tester import ContractTester
from pathlib import Path
from datasets import load_dataset, Dataset
import os, time, signal, subprocess, fcntl
import tempfile
from typing import Dict, List

class HumanEvalTester(ContractTester):
    """
    Given a function in HumanEval CPP dataset with a corresponding postcondition, this class runs relevant unit tests to
    check if the postcondition holds.
    """
    def __init__(self, root_dir, **kwargs):
        kwargs['use_cache'] = False # Humaneval testing is cheap we do not need to cache it
        self.dataset = Dataset.from_file('/home/tarun/.cache/huggingface/datasets/bigcode___humanevalpack/cpp/1.0.0/2ec06c14856114467362bcc8fa57b9878ec4873bd1ffd375878b5f0a238\
1f652/humanevalpack-test.arrow') 
        #load_dataset("bigcode/humanevalpack", "cpp", trust_remote_code=True)["test"]
        super().__init__(root_dir=root_dir, **kwargs)

    def _check_build(self):
        """
        For HumanEval this should always be ok.
        """
        pass

    def check_assertion(self, fn: FunctionData, assertion: str, worker_id: int, precondition: str = None):
        """
        The output is written to data/humaneval/result.csv file
        """
        test_string = fn.test_string # This consists of all tests
        function_string = fn.function_string

        # Replace all the `return` expressions in the function with the stub that checks the
        # postcondition as assertion
        # TODO: Refactor this into a method that can be used for all testers
        tmp_var_string = r"{auto res_tmp = \g<1>;"
        create_file = f"std::ofstream f; f.open(std::string(\"{self._tmp_result_files[worker_id]}\"), std::ios::app); "
        new_code_stub = tmp_var_string + create_file + f"f << __FUNCTION__ << \" \" << ({assertion}) << std::endl; f.close(); return res_tmp;}}"

        function_string = re.sub(r'return(.*);', new_code_stub, function_string)
        
        # Add precondition assertion at the beginning of function body if provided
        if precondition:
            # Find the opening brace of the function and insert assertion after it
            brace_pos = function_string.find('{')
            if brace_pos != -1:
                pre_assertion = f"assert({precondition});"
                function_string = function_string[:brace_pos+1] + pre_assertion + function_string[brace_pos+1:]

        program = function_string + test_string
        program = f'#include <fstream>\n#include <cassert>\n#include "{self.sep_conj_file}"\n' + program

        with tempfile.NamedTemporaryFile(suffix='.cpp', delete=True) as f:
            f.write(program.encode("utf-8"))
            f.flush()
            res = ContractTester.eval_cpp_file(Path(f.name))

        if res != None:
            output_txt = res['stdout'] + "\n" + res['stderr']
        else:
            output_txt = ""

        result = self._aggregate_results(fn, assertion, res['exit_code'], output_txt, worker_id)
        return result
