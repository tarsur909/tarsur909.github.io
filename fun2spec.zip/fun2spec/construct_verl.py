from llm_generator.prompt_builder import build_prompt
import os
from code_miner.code_miner import MBCPPMiner, HumanEvalMiner
from datasets import Dataset

os.environ['CURL_CA_BUNDLE'] = 'CABundle.pem'
HF_ACCESS_TOKEN = os.environ['HF_ACCESS_TOKEN'] if 'HF_ACCESS_TOKEN' in os.environ else None

def build_ds(split):
    if split == 'train':
        miner = MBCPPMiner('mbcpp')
    else:
        miner = HumanEvalMiner('humaneval')

    fn_datas = miner.filter_by_return_type(return_type='all', with_docstring=True)
    ds = []
    for idx, fn_data in enumerate(fn_datas):
        prompt = build_prompt(
            fn_data,
            None,
            add_doc=False,
            add_cot=True,
            add_ret_type=False,
            few_shot=4,
            quantifier_prompt=True
            )

        fn_kwargs = fn_data.__dict__
        fn_kwargs.pop('return_type')
        data = {
                    "data_source": "mbcpp",
                    "prompt": prompt,
                    "ability": "code",
                    "reward_model": {"style": "rule", "ground_truth": ''},
                    "extra_info": {
                        "split": split,
                        "index": idx,
                        **fn_kwargs

                    },
        }
        ds.append(data)

    return Dataset.from_list(ds)

train_dataset = build_ds('train')
test_dataset = build_ds('test')

train_dataset.to_parquet('train.parquet')
test_dataset.to_parquet('test.parquet')



