from collections import defaultdict
import fire
import queue
import common, torch
from pathlib import Path
from typing import List, Optional
from time import time, perf_counter, sleep
from common import GeneratorType, SourceType, setup_logging
from code_miner import get_code_miner
from baselines.daikon import DaikonGenerator
from function_data import FunctionData
from spec import Postcondition
from tester.contract_tester import ContractTester
from tester import get_contract_tester
from llm_generator.fs_generator import FSGenerator
import subprocess
import logging
import os
import requests
from functools import partial
from concurrent.futures import ProcessPoolExecutor
import multiprocessing
import traceback
import json
from code_miner.ts_parser import detect_quantifier_implies
from llm_generator.postcondition import validate_precondition

logger = logging.getLogger(__name__)


def execute_shell_command(command: str) -> subprocess.Popen:
    """
    Execute a shell command and return its process handle.
    """
    command = command.replace("\\\n", " ").replace("\\", " ")
    parts = command.split()
    return subprocess.Popen(parts, text=True, stderr=subprocess.STDOUT)


def launch_server_cmd(model_name: str):
    """
    Launch the server using the given command.
    """
    process = execute_shell_command(f"python3 sglang_server.py --model_name {model_name}")
    return process


def terminate_process(process):
    """
    Terminate the process and automatically release the reserved port.
    """
    from sglang.srt.utils import kill_process_tree

    kill_process_tree(process.pid)


def wait_for_server(base_url: str, timeout: int = 300) -> None:
    """Wait for the server to be ready by polling the endpoint.

    Args:
        base_url: The base URL of the server
        timeout: Maximum time to wait in seconds. None means wait forever.
    """
    start_time = perf_counter()
    while True:
        try:
            response = requests.get(f"{base_url}/get_server_status")
            if response.status_code == 200:
                sleep(5)
                print(
                    """\n
                    Server up and running!
                    """
                )
                break

            if timeout and perf_counter() - start_time > timeout:
                raise TimeoutError("Server did not become ready within timeout period")
        except requests.exceptions.RequestException:
            sleep(1)


def worker(worker_id, task_queue, result_queue, free_workers, spec_task_fn, error_queue):
    """
    Worker process.
    Accepts tasks of either:
      - legacy: (fn_idx, prev_result)
      - combos: (combo_idx, fn_idx, logic, use_quantifiers, prev_result)
    Always returns a tuple prefixed with combo_idx (or 0 for legacy):
      (combo_idx, fn_idx, raw_post, result, cannot_parse, cannot_translate, post, test_time, gen_time, raw_pre, pre, cannot_parse_pre, cannot_translate_pre)
    """
    free_workers.put(worker_id)
    while True:
        task = task_queue.get()
        if task is None:
            break
        # detect task shape
        if len(task) == 2:
            idx, prev_result = task
            combo_idx, logic, use_quants = 0, 'fol', False
        else:
            combo_idx, idx, logic, use_quants, prev_result = task
        try:
            # generate and test postcondition (and precondition) for specified combo
            res = spec_task_fn(idx, prev_result, logic=logic, use_quantifiers=use_quants, worker_id=worker_id)
            # Res is: [idx, raw_post, result, cannot_parse, cannot_translate, post, test_time, gen_time, raw_pre, pre, cannot_parse_pre, cannot_translate_pre]
            result_queue.put((combo_idx, *res))
            free_workers.put(worker_id)
        except Exception as e:
            tb = traceback.format_exc()
            error_queue.put((worker_id, e, tb))
            break


def run_mp(count, num_parallel_workers, spec_task_fn, total_attempts, combos=None):
    """
    Dynamic multiprocessing runner supporting reprompting across (fn, combo) pairs.

    spec_task_fn(fn_idx, prev_result, logic, use_quantifiers, worker_id) ->
       [idx, raw_post, result, cannot_parse, cannot_translate, post, test_time, gen_time, 
        raw_pre, pre, cannot_parse_pre, cannot_translate_pre]

    If combos is None, behaves like legacy single-combo run, with combo_idx=0.
    """
    free_workers = multiprocessing.Queue()
    task_queues = [multiprocessing.Queue() for _ in range(num_parallel_workers)]
    result_queue = multiprocessing.Queue()
    error_queue = multiprocessing.Queue()

    # Normalize combos
    if not combos:
        combos = [('fol', False)]

    # Initial tasks: each (combo, fn) with no prev_result
    pending = set((cidx, i) for cidx, _ in enumerate(combos) for i in range(count))
    tasks = [(cidx, i, combos[cidx][0], combos[cidx][1], None)
             for cidx, _ in enumerate(combos) for i in range(count)]

    attempt = 0

    # Start worker processes
    processes = []
    for wid in range(num_parallel_workers):
        p = multiprocessing.Process(
            target=worker,
            args=(wid, task_queues[wid], result_queue, free_workers, spec_task_fn, error_queue)
        )
        p.start()
        processes.append(p)

    def check_error_and_abort():
        try:
            wid, err, tb = error_queue.get_nowait()
        except queue.Empty:
            return
        for p in processes:
            p.terminate()
        raise RuntimeError(f"Worker {wid} crashed with:\n{tb}")

    # results[(fn_idx, combo_idx)][attempt] -> payload
    results = {}
    dispatched = set()

    # Dispatch and dynamic loop
    while pending or dispatched:
        # dispatch tasks as long as workers free and tasks remain
        while tasks and not free_workers.empty():
            wid = free_workers.get()
            task = tasks.pop(0)
            if len(task) == 2:
                # legacy shape, unreachable with normalized combos, kept for safety
                idx, prev_res = task
                task_queues[wid].put((idx, prev_res))
                dispatched.add((0, idx))
            else:
                cidx, idx, logic, use_quants, prev_res = task
                task_queues[wid].put((cidx, idx, logic, use_quants, prev_res))
                dispatched.add((cidx, idx))

        # collect results
        try:
            check_error_and_abort()
            res = result_queue.get(timeout=1)
        except queue.Empty:
            continue
        combo_idx, idx, raw_post, result, cannot_parse, cannot_translate, post, test_time, gen_time, raw_pre, pre, cannot_parse_pre, cannot_translate_pre = res

        key = (idx, combo_idx)
        if key in results:
            curr_attempt = max(results[key].keys()) + 1
        else:
            results[key] = {}
            curr_attempt = 1

        results[key][curr_attempt] = (idx, raw_post, result, cannot_parse, cannot_translate, post, test_time, gen_time, raw_pre, pre, cannot_parse_pre, cannot_translate_pre)
        if (combo_idx, idx) in dispatched:
            dispatched.remove((combo_idx, idx))

        # if reprompt needed, schedule again
        if curr_attempt < total_attempts and result and (
            result['result'] in ['Compilation error', 'Cannot Parse', 'Cannot Translate', False]
            or (result.get('is_strongest_indicator') == False)
            or (result.get('pre_validation_error') == True)
        ):
            # schedule reprompt for the same (fn, combo) with prev_result
            tasks.append((combo_idx, idx, combos[combo_idx][0], combos[combo_idx][1], result))
            pending.add((combo_idx, idx))
        else:
            if (combo_idx, idx) in pending:
                pending.discard((combo_idx, idx))

        check_error_and_abort()

    # shutdown workers
    for _ in range(num_parallel_workers):
        wid = free_workers.get()
        task_queues[wid].put(None)
    for p in processes:
        p.join()

    # Repackage as: list indexed by fn_idx -> dict[combo_idx] -> dict[attempt] -> payload
    packaged = []
    for i in range(count):
        by_combo = {}
        for cidx, _ in enumerate(combos):
            key = (i, cidx)
            if key in results:
                by_combo[cidx] = results[key]
        packaged.append(by_combo)
    return packaged


def get_combos(logic, use_quantifiers):
    """
    Build the list of (logic, use_quantifiers) combos.

    When logic == 'sep' and use_quantifiers == True, we expect four combos:
      [('fol', False), ('fol', True), ('sep', False), ('sep', True)]
    Otherwise, fewer are valid and no fixed length is asserted.
    """
    combos = [('fol', False)]
    if use_quantifiers:
        combos.append(('fol', True))
    if logic == 'sep':
        combos.append(('sep', False))
        if use_quantifiers:
            combos.append(('sep', True))
            assert len(combos) == 4  # only in this case
    return combos


def run(
        source,
        model_name:str='microsoft/Phi-3-mini-128k-instruct',
        model_port:int = 8080,
        cached_model_path:str = None,
        gen_backend:str = 'transformers',
        return_type:str='int',
        use_cache:bool=True,
        run_parallel:bool=False,
        num_parallel_workers:int = os.cpu_count(),
        count:int=100,
        timeout:float=60,
        add_doc:bool=False,
        add_cot: bool=True,
        add_ret_type: bool=True,
        few_shot:int=4,
        use_quantifiers:bool=False,
        debug_example_id:Optional[int]=None,
        debug_function_paths:Optional[List[str]] = None,
        gen_name:str='fun2spec',
        quant_bits:Optional[int]=None,
        total_attempts: int = 1,
        max_new_tokens:int=400,
        nl2post=False,
        strongest_post_prompt = False,
        logic = 'fol',
        gen_pre: bool = False,
        **kwargs
    ):
    assert gen_backend in ['transformers', 'sglang']

    num_parallel_workers = min(num_parallel_workers, count, float('inf') if run_parallel else 1)

    sglang_server = None
    try:
        if gen_backend == 'sglang':
            if cached_model_path is not None:
                sglang_server = launch_server_cmd(cached_model_path)
            else:
                sglang_server = launch_server_cmd(model_name)
            wait_for_server(f"http://localhost:{model_port}")

        setup_logging()
        start_time = time()
        # Check all provided arguments are expected
        assert len(kwargs) == 0, f"Invalid arguments {kwargs}"
        assert not (debug_example_id and debug_function_paths), "Only one of debug_example_id and debug_function_paths can be set"

        source_type: SourceType = common.get_source_name(source)
        logger.info(f"Analyzing {source_type}...")

        # Code in the repository is analyzed to extract the functions and relevant metadata
        miner = get_code_miner(source=source, use_cache=use_cache)

        # For BDE and humaneval docstring is available, and thus we filter functions with docstring
        with_docstring = source_type in [SourceType.humaneval, SourceType.BDE, SourceType.mbcpp]

        # Filter functions according to the return type
        filtered_functions = miner.filter_by_return_type(return_type=return_type, with_docstring=with_docstring)
        logger.info(f"Filtered {len(filtered_functions)} functions. In the evaluation, {min(count, len(filtered_functions))} will be used.")
        # Create the specification generator
        spec_gen_class = common.get_generator(gen_name)
        if spec_gen_class == GeneratorType.Fun2Spec:
            spec_generator = FSGenerator(
                model_name=model_name,
                model_port=model_port,
                gen_backend = gen_backend,
                add_doc=add_doc,
                add_cot=add_cot,
                add_ret_type=add_ret_type,
                few_shot=few_shot,
                quant_bits=quant_bits,
                max_new_tokens=max_new_tokens,
                nl2post=nl2post,
                strongest_post_prompt = strongest_post_prompt
                )
        else:
            if source_type == SourceType.file \
                or source_type == SourceType.humaneval:
                spec_generator = DaikonGenerator()
            else:
                raise ValueError(f'Generator {spec_gen_class} is not implemented yet for {source_type}!')

        # Prepare the tester
        ctester = get_contract_tester(
            source_type, root_dir=source, timeout=timeout, use_cache=use_cache, num_parallel_workers = num_parallel_workers)

        # Filter functions with test target
        if 'filter_fns_with_test_target' in dir(ctester):
            filtered_functions = ctester.filter_fns_with_test_target(filtered_functions)
            logger.info(f"Extracted {len(filtered_functions)} functions with test targets.")

        if debug_function_paths is not None:
            filtered_functions = [func for func in filtered_functions if f"{func.file_path}/{func.function_name}" in debug_function_paths]

        if debug_example_id is not None:
            filtered_functions = [filtered_functions[debug_example_id]]

        meta_stats = defaultdict(int)
        sum_test_time, cnt_fns_tested, sum_gen_time = 0, 0, 0
        task_to_post, results, raw_gens, all_posts = {}, [], [], []
        filtered_functions = filtered_functions[:count]
        count = len(filtered_functions[:count])

        # GPU memory info (best-effort; don't crash if CUDA missing)
        try:
            if torch.cuda.is_available():
                total_memory = torch.cuda.get_device_properties(0).total_memory
                allocated_memory = torch.cuda.memory_allocated(0)
                free_memory = (total_memory - allocated_memory)/(1024**3)
                logger.info(f"Free GPU memory: {free_memory:.2f} GB")
            else:
                logger.info("CUDA not available; running on CPU.")
        except Exception:
            logger.info("Unable to query CUDA memory info.")

        # define a task fn that defers logic/use_quantifiers to the task itself
        def spec_gen_fnc(fn_idx, prev_result, logic, use_quantifiers, worker_id=0):
            return generate_post(
                idx=fn_idx,
                prev_result=prev_result,
                filtered_functions=filtered_functions,
                spec_generator=spec_generator,
                ctester=ctester,
                nl2post=nl2post,
                logic=logic,
                use_quantifiers=use_quantifiers,
                worker_id=worker_id,
                gen_pre=gen_pre
            )

        combos = get_combos(logic, use_quantifiers)
        all_res = run_mp(count, num_parallel_workers, spec_gen_fnc, total_attempts, combos=combos)

        for fn_idx, res_by_combo in enumerate(all_res):
            # =========================
            # Selection that unions correctness across combos
            # Priority: sep True > sep False > fol True > fol False
            # =========================
            def priority_key(cidx):
                logic_key, uq = combos[cidx]
                return (1 if logic_key == 'sep' else 0, 1 if uq else 0)  # higher is better

            prio = sorted(range(len(combos)), key=priority_key, reverse=True)

            def best_attempt(attempts):
                # attempts: dict[attempt_id] -> payload
                # payload = (idx, raw_post, result, cannot_parse, cannot_translate, post, test_time, gen_time, raw_pre, pre, cannot_parse_pre, cannot_translate_pre)
                # Pick in this order: strongest True > heap-ok True > any True
                for aid, payload in attempts.items():
                    res = payload[2]
                    if res and res.get('result') is True and res.get('is_strongest_indicator') is True:
                        return aid
                for aid, payload in attempts.items():
                    res = payload[2]
                    if res and res.get('result') is True and res.get('should_heap_but_isnt') is False:
                        return aid
                for aid, payload in attempts.items():
                    res = payload[2]
                    if res and res.get('result') is True:
                        return aid
                return None

            chosen_combo, chosen_attempt = None, None
            for cidx in prio:
                attempts = res_by_combo.get(cidx, {})
                if not attempts:
                    continue
                cand = best_attempt(attempts)
                if cand is not None:
                    chosen_combo, chosen_attempt = cidx, cand
                    break

            # Fallback: if nothing was True anywhere, pick the latest attempt from
            # the highest-priority combo that has any attempt.
            if chosen_combo is None:
                for cidx in prio:
                    attempts = res_by_combo.get(cidx, {})
                    if attempts:
                        chosen_combo = cidx
                        chosen_attempt = max(attempts.keys())
                        break

            attempts = res_by_combo.get(chosen_combo, {})
            idx, raw_post, result, cannot_parse, cannot_translate, post, _, _, raw_pre, pre, cannot_parse_pre, cannot_translate_pre = attempts[chosen_attempt]

            # time accounting: sum only for the chosen combo (sum across attempts of that combo)
            # gen_time is at index 7, test_time is at index 6
            gen_time = sum(v[7] for v in attempts.values())
            test_time = sum(v[6] for v in attempts.values())
            sum_gen_time += gen_time
            sum_test_time += test_time
            cnt_fns_tested += 1
            raw_gens.append(raw_post)
            task_to_post[idx] = post
            if result is not None:
                # annotate chosen combo metadata on the result
                chosen_logic, chosen_use_quants = combos[chosen_combo]
                result['use_quantifiers'] = chosen_use_quants
                result['logic'] = chosen_logic
                results.append(result)
            all_posts.append(post)
            if cannot_parse:
                meta_stats['cannot_parse'] += 1
            if cannot_translate:
                meta_stats['cannot_translate'] += 1
            if cannot_parse_pre:
                meta_stats['cannot_parse_pre'] += 1
            if cannot_translate_pre:
                meta_stats['cannot_translate_pre'] += 1

        meta_stats['avg_gen_time'] = str(round(sum_gen_time/len(filtered_functions[:count]), 2)) if count else "0"
        meta_stats['avg_test_time'] = str(round(sum_test_time/cnt_fns_tested, 2)) if cnt_fns_tested else "0"
        ovr_exec_time = time() - start_time
        # Read the output and compute statistics
        if source_type != SourceType.file:
            compute_stats(
                source,
                results,
                len(filtered_functions[:count]),
                task_to_post,
                model_name=model_name,
                return_type=return_type,
                use_cache=use_cache,
                count=count,
                timeout=timeout,
                add_doc=add_doc,
                add_cot=add_cot,
                few_shot=few_shot,
                add_ret_type=add_ret_type,
                use_quantifiers=use_quantifiers,
                gen_name=gen_name,
                raw_gens=raw_gens,
                meta_stats=meta_stats,
                total_attempts=total_attempts,
                ovr_exec_time = ovr_exec_time,
                strongest_post_prompt = strongest_post_prompt,
                logic = logic,
                gen_pre=gen_pre,
                **kwargs
            )
            return results
        else:
            return task_to_post # no testcases for file so just return post

    except Exception as e:
        raise e
    finally:
        if gen_backend == 'sglang' and sglang_server is not None:
            terminate_process(sglang_server)
        torch.cuda.empty_cache()


def is_strongest_indicator(function_string, predicate, logic):
    constructs = detect_quantifier_implies(function_string)
    error_msg = None
    error_prefix = "The postcondition you generated is not the strongest. The strongest postcondition is the most precise predicate that holds in every possible final state reachable after the function's execution."
    quantifiers = ['FORALL', 'EXISTS']
    if logic == 'sep':
        sep_quantifiers = ['SEPFORALL', 'SEPEXISTS']
        quantifiers.extend(sep_quantifiers)
    if 'quantifier' in constructs and all([quantifier not in predicate for quantifier in quantifiers]):
        error_msg = error_prefix + "Your postcondition is missing quantifiers " + " and/or ".join(quantifiers)
    if logic == 'sep' and any(sep_quantifier in predicate for sep_quantifier in sep_quantifiers) and '↦' not in predicate:
        if error_msg is None:
            error_msg = error_prefix + 'The condition in SEPFORALL or SEPEXISTS may be missing "↦" operator.'
        else:
            error_msg += 'The condition in SEPFORALL or SEPEXISTS may be missing "↦" operator.'

    if 'implication' in constructs and "==>" not in predicate:
        if error_msg is None:
            error_msg = error_prefix + 'Your postcondition is missing implication "==>".'
        else:
            error_msg += 'Your postcondition is also missing implication "==>".'
    return error_msg


def generate_post(
        idx: int,
        prev_result,
        filtered_functions:List,
        spec_generator:FSGenerator,
        ctester:ContractTester,
        nl2post:bool=False,
        logic:str = 'fol',
        use_quantifiers:bool = False,
        worker_id = 0,
        gen_pre: bool = False
    ):
    logger.info(f"Example {idx+1} {'-'*50}")
    start_time = time()
    batch_fns = filtered_functions[idx]

    if logic == 'sep':
        if prev_result is not None:
            fn_on_heap = prev_result['fn_on_heap']
        else:
            fn_on_heap = ctester.check_on_heap(batch_fns, worker_id)
    else:
        fn_on_heap = False

    if prev_result is not None:
        post, raw_post = spec_generator.get_postcondition([batch_fns],
                prev_result=prev_result, logic=logic, use_quantifiers=use_quantifiers)[0]
    else:
        post, raw_post = spec_generator.get_postcondition([batch_fns], logic=logic, use_quantifiers=use_quantifiers)[0]

    # Generate precondition if gen_pre is True and postcondition was generated
    pre, raw_pre = None, None
    if gen_pre and post is not None and post.predicate is not None:
        if prev_result is not None and 'pre_error_msg' in prev_result:
            pre, raw_pre = spec_generator.get_precondition(
                batch_fns, 
                post.predicate, 
                prev_result=prev_result, 
                logic=logic, 
                use_quantifiers=use_quantifiers
            )
        else:
            pre, raw_pre = spec_generator.get_precondition(
                batch_fns, 
                post.predicate, 
                logic=logic, 
                use_quantifiers=use_quantifiers
            )
        logger.info(f"Generated precondition: {pre.predicate if pre else 'None'}")

    # Store time for generation
    gen_time = time()-start_time
    logger.info(f"Time for invariant generation: {round(gen_time, 2)}")

    test_time = time()
    fn_data = filtered_functions[idx]

    # Test the generated postcondition (and precondition if generated)
    result = None
    result, cannot_parse, cannot_translate, error_msg, cannot_parse_pre, cannot_translate_pre = test_post(
        ctester, post, fn_data, nl2post, worker_id, precondition=pre
    )

    if result is None:
        result = {'true': 0, 'false': 0, 'return_code': 0}
        if cannot_parse:
            result['result'] = 'Cannot Parse'
        elif cannot_translate:
            result['result'] = 'Cannot Translate'
        elif cannot_parse_pre:
            result['result'] = 'Cannot Parse Precondition'
        elif cannot_translate_pre:
            result['result'] = 'Cannot Translate Precondition'
        else:
            result['result'] = 'Result is None Unknown'
    else:
        if result['result'] == False:
            error_msg = "Generated postcondition is not valid for all inputs."
        elif result['result'] == 'Compilation error':
            error_msg = result['error_output']

    result['function_name'] = fn_data.function_name

    result['should_heap_but_isnt'] = False
    if use_quantifiers == True:
        result['is_strongest_indicator'] = False
        if result['result'] == True:
            error_msg = is_strongest_indicator(fn_data.function_string, post.predicate, logic)
            if error_msg is None:
                result['is_strongest_indicator'] = True
    else:
        result['is_strongest_indicator'] = False

    if fn_on_heap:
        has_sep = any(op in post.predicate for op in ['↦', '⋆']) if post.predicate is not None else False
        if not has_sep:
            result['is_strongest_indicator'] = False
            result['should_heap_but_isnt'] = True
            error_addition = '\nGenerated postcondition is missing ↦ and/or ⋆ operators. The C++ function manipulates the heap and thus requires a postcondition in separation logic.'
            error_msg = error_msg + error_addition if error_msg is not None else error_addition

    if post is not None:
        result['raw_gen'] = post.raw
    
    # Store precondition info in result
    if gen_pre:
        result['raw_gen_pre'] = raw_pre if raw_pre else None
        result['pre_error_msg'] = error_msg if (cannot_parse_pre or cannot_translate_pre) else None
        if pre and pre.predicate:
            result['precondition'] = pre.predicate
            # Validate precondition: ensure only function parameter names are used
            # and no arbitrary function calls are present
            pre_validation_error = validate_precondition(
                pre.predicate, 
                fn_data.args,  # Only function parameter names allowed
                logic
            )
            if pre_validation_error:
                result['pre_validation_error'] = True
                # Concatenate with existing pre_error_msg instead of overwriting
                if result.get('pre_error_msg'):
                    result['pre_error_msg'] += " " + pre_validation_error
                else:
                    result['pre_error_msg'] = pre_validation_error
                if error_msg is None:
                    error_msg = pre_validation_error
                else:
                    error_msg = error_msg + " " + pre_validation_error
            else:
                result['pre_validation_error'] = False
        else:
            # Precondition wasn't generated or parsed - set validation error to False
            result['pre_validation_error'] = False

    result['error_msg'] = error_msg
    result['function_string'] = fn_data.function_string
    result['fn_on_heap'] = fn_on_heap

    test_time = time() - test_time
    logger.info(f"Total time for testing postcondition: {round(test_time, 2)}")
    return [idx, raw_post, result, cannot_parse, cannot_translate, post, test_time, gen_time, raw_pre, pre, cannot_parse_pre, cannot_translate_pre]


def test_post(ctester,  post: Postcondition, fn_data: FunctionData, nl2post=False, worker_id = 0, precondition=None):
    result = None
    cannot_parse, cannot_translate = 0, 0
    cannot_parse_pre, cannot_translate_pre = 0, 0
    error_msg = None
    pre_cpp_expr = None
    
    # Handle precondition if provided
    if precondition is not None:
        if precondition.predicate is not None:
            if nl2post:
                pre_cpp_expr = precondition.predicate
                trans_error_msg_pre = None
            else:
                pre_cpp_expr, trans_error_msg_pre = precondition.get_cpp_expression()
            
            if pre_cpp_expr is None:
                cannot_translate_pre += 1
                error_msg = trans_error_msg_pre
                logger.info("Cannot translate the precondition!")
            else:
                logger.info("Precondition:")
                print(precondition.predicate)
        else:
            cannot_parse_pre += 1
            error_msg = f"The precondition in your output:\n{precondition.raw}\n is not wrapped in PRE(). Fix the issue by generating PRE(correct_precondition)."
            logger.info("Cannot parse the precondition!")
    
    if post is not None:
        if post.predicate is not None:
            if nl2post:
                cpp_expr = post.predicate
                trans_error_msg = None
            else:
                cpp_expr, trans_error_msg = post.get_cpp_expression()

            if cpp_expr is not None:
                result = ctester.check_assertion(fn_data, cpp_expr, worker_id, precondition=pre_cpp_expr)

                if result is not None:
                    result['postcondition'] = post.predicate
                    if precondition and precondition.predicate:
                        result['precondition'] = precondition.predicate

                logger.info("Reasoning:")
                print(post.reasoning)

                logger.info("Postcondition:")
                print(post.predicate)
            else:
                # In this case the postcondition cannot be translated correctly
                cannot_translate += 1
                error_msg = trans_error_msg if error_msg is None else error_msg
                logger.info("Cannot translate the postcondition!")
        else:
            # Unable to extract the postcondition from the output
            cannot_parse += 1
            error_msg = f"The postcondition in your output:\n{post.raw}\n is not wrapped in POST(). Fix the issue by generating POST(correct_postcondition)."
            logger.info("Cannot parse the postcondition!")
    return result, cannot_parse, cannot_translate, error_msg, cannot_parse_pre, cannot_translate_pre


def compute_stats(
        source,
        results: dict,
        total,
        task_to_post,
        model_name:str="microsoft/Phi-3-mini-128k-instruct",
        return_type:str='int',
        use_cache:bool=True,
        count:int=50,
        timeout:float=30,
        add_doc:bool=False,
        add_cot: bool=True,
        add_ret_type: bool=True,
        use_quantifiers: bool=True,
        gen_name:str='fun2spec',
        raw_gens=[],
        meta_stats=None,
        few_shot=4,
        total_attempts=1,
        ovr_exec_time = 0,
        strongest_post_prompt = False,
        logic = 'fol',
        gen_pre: bool = False,

        **kwargs
        ):
        """
        Read the output in result.jsonl file and and compute statistics
        """
        # Copy result file path in another place
        log_path = f"{common.get_project_path()}/data/{common.get_source_name(source)}/{model_name}/"
        log_file_name = f"gen_name:{gen_name}_logic:{logic}_return_type:{return_type}_count:{count}_cot:{add_cot}_ret:{add_ret_type}_few_shot:{few_shot}_total_attempts:{total_attempts}"
        log_file_name += f"_us_quantifiers:{use_quantifiers}_us_strongest:{strongest_post_prompt}_gen_pre:{gen_pre}"

        fn_heap_cache_path = f"{common.get_project_path()}/data/{common.get_source_name(source)}/fn_heap_cache.json"

        log_res_path = f"{log_path}/{log_file_name}.jsonl"
        log_raw_gens = f"{log_path}/{log_file_name}_raw_output.txt"

        Path(log_path).mkdir(parents=True, exist_ok=True)

        # Store raw generation
        with open(log_raw_gens, 'w') as f:
            for line in raw_gens:
                f.write(f"{line}\n")

        count_test_valid, count_test_invalid, count_clang_issue, count_no_test, count_compile_error, count_strongest = 0, 0, 0, 0, 0, 0
        count_with_precondition = 0
        count_total = 0
        fn_heap_cache = {}
        # Per-combo summary based on the selected combo per problem
        combo_stats = defaultdict(lambda: {"selected": 0, "correct": 0, "strongest": 0})

        with open(log_res_path, 'w') as lf:
            for idx, result in enumerate(results):
                # res_json = json.loads(res.replace("'", "\""))
                cnt_true, cnt_false, return_code = result['true'], result['false'], result['return_code']
                cnt_true, cnt_false = int(cnt_true), int(cnt_false)
                fn_heap_cache[result['function_name']] = result['fn_on_heap']

                # Global counters
                count_test_valid += (result["result"] == True)
                count_test_invalid += (result["result"] == False)
                count_no_test += (result['result'] == "No test")
                count_clang_issue += (result['result'] == "Clang Error")
                count_compile_error += (result['result'] == "Compilation error")
                count_strongest += (result['is_strongest_indicator'] == True)
                count_total += (result["result"] == True or result["result"] == False or result['result'] == "Compilation error")
                
                # Count preconditions generated
                if gen_pre and 'precondition' in result:
                    count_with_precondition += 1

                # Per-combo (based on selected combo for this function)
                combo_key = (result.get('logic', 'fol'), bool(result.get('use_quantifiers', False)))
                combo_stats[combo_key]["selected"] += 1
                combo_stats[combo_key]["correct"] += int(result.get("result") == True)
                combo_stats[combo_key]["strongest"] += int(result.get("is_strongest_indicator") == True)

                if idx in task_to_post:
                    # Add reasoning in the output if it was parsed correctly in the output
                    result['reasoning'] = task_to_post[idx].reasoning

                # Store the updated JSON back to the new result log file
                lf.write(str(result) + '\n')

        count_total = count_total + meta_stats['cannot_parse'] + meta_stats['cannot_translate']

        # print(f"Postcondition generated for: {len(results)}/{count_total}")
        print(f"Does not compile, timeout reached: {count_compile_error}/{count_total}")
        print(f"No test exists: {count_no_test}/{count_total}")

        print(f"Postcondition always hold: {count_test_valid}/{count_total}")
        print(f"Postcondition does not hold in some cases: {count_test_invalid}/{count_total}")
        print(f"Postcondition is strongest based on parsing indicator: {count_strongest}/{count_total}")
        
        if gen_pre:
            print(f"Preconditions generated: {count_with_precondition}/{count_total}")

        # Per-combo performance (based on selected combo per problem)
        print("Per-combo performance (based on selected combo per problem):")
        for (logic_key, uq_key), s in combo_stats.items():
            sel = s["selected"]
            corr = s["correct"]
            strg = s["strongest"]
            pc = round(corr / sel, 4) if sel else 0.0
            ps = round(strg / sel, 4) if sel else 0.0
            print(f"  Combo logic={logic_key}, use_quantifiers={uq_key} -> selected {sel}, correct {corr} (p={pc}), strongest {strg} (p={ps})")

        print(f"Check more detailed results in {log_res_path}")

        # Build serializable combo summary for the results file
        combo_summary = {
            f"{k[0]}|{k[1]}": {
                "selected": v["selected"],
                "correct": v["correct"],
                "strongest": v["strongest"],
                "prop_correct": round(v["correct"]/v["selected"], 4) if v["selected"] else 0.0,
                "prop_strongest": round(v["strongest"]/v["selected"], 4) if v["selected"] else 0.0,
            }
            for k, v in combo_stats.items()
        }

        # Store the result summary in a file
        result_summary = {
            "source": source,
            "model_name": model_name,
            "gen_name": gen_name,
            "return_type": return_type,
            "use_cache": use_cache,
            "count": count,
            "Postcondition test-valid": f"{count_test_valid}",
            "Postcondition test-invalid": f"{count_test_invalid}",
            "Compile Error": f"{count_compile_error}",
            "Clang Error": f"{count_clang_issue}",
            "No test exists": f"{count_no_test}",
            "Strongest By Parsing Indicator": f"{count_strongest}",
            "Preconditions Generated": f"{count_with_precondition}" if gen_pre else "N/A",
            "meta stats": meta_stats,
            "timeout": timeout,
            "add_doc": add_doc,
            "add_cot": add_cot,
            "add_ret_type": add_ret_type,
            "use_quantifiers": use_quantifiers,
            "few_shot": few_shot,
            "total_attempts": total_attempts,
            "ovr_exec_time": ovr_exec_time,
            "gen_pre": gen_pre,
            "per_combo_summary": combo_summary
        }
        print(result_summary)
        print(f"Overall Experiment Runtime: {round(ovr_exec_time, 2)}")
        # Add a line to the results file
        with open('data/results.jsonl', 'a') as f:
            f.write(str(result_summary) + '\n')

        if use_cache and not os.path.exists(fn_heap_cache_path):
            with open(fn_heap_cache_path, 'w') as fnf:
                json.dump(fn_heap_cache, fnf)


if __name__ == "__main__":
    multiprocessing.set_start_method('spawn')
    fire.Fire(run)
