from lark import Lark, Token, Tree, Transformer as LarkTransformer
import logging
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Set, Any

logger = logging.getLogger(__name__)


# =========================
# First-Order Logic (FOL)
# =========================
fol_grammar = r"""
    start: expression -> start_expr

    // Logical expressions
    expression: implication
              | quantifier_expression
              | comp_expression
              | "(" expression ")"

    implication : expression "==>" expression -> implication
    !comp_expression: operation_expression
                    | expression ( "||" | "&&" ) expression -> binary_op

    !quantifier_expression: exists_expr | forall_expr
    exists_expr: EXISTST "(" expression "," expression "," CNAME "," expression ")" -> exists_expr
    forall_expr: FORALL "(" expression "," expression "," CNAME "," expression ")" -> forall_expr
    EXISTST.2: "EXISTS"
    FORALL.2: "FORALL"

    operation_expression: binary_op | unary_expr
    unary_expr: unary | atom

    !binary_op : expression binary_operator expression -> binary_op
    !unary: UNARY_OP expression -> unary_op
    !binary_operator: COMPARISON_OP | ARITHMETIC_OP | BITWISE_OP

    // Atoms: Base cases like variables, literals, functions, etc.
    atom: variable
        | literal
        | string_literal
        | pointer_access
        | array_access
        | function_call
        | "(" expression ")"  -> paren_expr
        | atom "." atom -> dot_expr
        | atom "->" atom -> arrow_expr
        | atom "::" atom -> scope_res

    // Components
    variable: CNAME
    literal: NUMBER | SIGNED_NUMBER | HEX_NUMBER | OCT_NUMBER | BIN_NUMBER
    !string_literal: /'.'/ | /".*?"/
    pointer_access: "*" expression
    array_access: expression "[" expression "]" -> array_access
    function_call: expression "(" (expression ("," expression)*)? ")"  -> function_call

    // Operators
    COMPARISON_OP: "==" | "!=" | "<" | ">" | "<=" | ">="
    ARITHMETIC_OP: "+" | "-" | "*" | "/" | "%" | "**"
    BITWISE_OP: "&" | "|" | "^" | "<<" | ">>"
    UNARY_OP: "!" | "-" | "~" | "++" | "--" | "*" | /(?<!&)&(?!&)/

    HEX_NUMBER.2: /0x[\da-f]*(u)?/i
    OCT_NUMBER.2: /0o[0-7]*(u)?/i
    BIN_NUMBER.2 : /0b[0-1]*(u)?/i

    %import common.CNAME
    %import common.NUMBER
    %import common.SIGNED_NUMBER
    %import common.ESCAPED_STRING
    %import common.WS
    %ignore WS
"""


class FOLTransformer:
    """Pure first-order logic transformer: quantifiers, implication, boolean/arith,
    field/method/array/pointer syntax. No separation-logic operators here."""
    def transform(self, tree):
        """Recursively transform the parse tree into a C++ expression string."""
        if isinstance(tree, Tree):
            if tree.data == "start_expr":
                return self.transform(tree.children[0])

            elif tree.data == "paren_expr":
                return f"({self.transform(tree.children[0])})"

            elif tree.data == "function_call":
                arg_str = ''
                for i in range(1, len(tree.children)):
                    if i > 1:
                        arg_str += ","
                    arg_str += self.transform(tree.children[i])
                return f"{self.transform(tree.children[0])}({arg_str})"

            elif tree.data == "exists_expr":
                # EXISTS(start, end, i, cond)
                start = self.transform(tree.children[1])
                end = self.transform(tree.children[2])
                var_name = tree.children[3].value  # CNAME token
                condition = self.transform(tree.children[4])
                return (
                    f"([&]() {{ for(int {var_name} = {start}; {var_name} < {end}; "
                    f"{var_name}++) {{ if({condition}) return true; }} return false; }})()"
                )

            elif tree.data == "forall_expr":
                # FORALL(start, end, i, cond)
                start = self.transform(tree.children[1])
                end = self.transform(tree.children[2])
                var_name = tree.children[3].value  # CNAME token
                condition = self.transform(tree.children[4])
                return (
                    f"([&]() {{ for(int {var_name} = {start}; {var_name} < {end}; "
                    f"{var_name}++) {{ if(!({condition})) return false; }} return true; }})()"
                )

            elif tree.data == "implication":
                left = self.transform(tree.children[0])
                right = self.transform(tree.children[1])
                return f"!({left}) || {right}"

            elif tree.data == "binary_op":
                left = self.transform(tree.children[0])
                right = self.transform(tree.children[2])
                return f"{left} {self.transform(tree.children[1])} {right}"

            elif tree.data == "dot_expr":
                left = self.transform(tree.children[0])
                right = self.transform(tree.children[1])
                return f"{left}.{right}"

            elif tree.data == "scope_res":
                left = self.transform(tree.children[0])
                right = self.transform(tree.children[1])
                return f"{left}::{right}"

            elif tree.data == "arrow_expr":
                left = self.transform(tree.children[0])
                right = self.transform(tree.children[1])
                # Spaces around '->' are fine in C++
                return f"{left} -> {right}"

            elif tree.data == "unary_op":
                return f"{self.transform(tree.children[0])}{self.transform(tree.children[1])}"

            elif tree.data == "array_access":
                return f"{self.transform(tree.children[0])}[{self.transform(tree.children[1])}]"

            else:
                # Passthrough single child
                return f"{self.transform(tree.children[0])}"

        elif isinstance(tree, Token):
            return tree.value

        return ""


# =========================
# Separation Logic (SEP)
# =========================
# =========================
# Separation Logic (SL)
# =========================
sep_grammar = r"""
    start: (pred_def ";")* expression -> start_expr

    // Expressions
    expression: implication
              | sl_expression
              | comp_expression
              | "(" expression ")"

    implication : expression "==>" expression -> implication

    // Separation logic (↦ binds tighter than ⋆)
    !sl_expression: sep_conj_expression
    !sep_conj_expression: mapsto_expression
                        | sep_conj_expression SEP_CONJ mapsto_expression -> sep_conj
    !mapsto_expression: comp_expression MAPSTO comp_expression -> mapsto
                      | comp_expression

    // Regular boolean/arith with sane precedence
    !comp_expression: logic_or
    !logic_or: logic_and
             | logic_or "||" logic_and              -> binary_op
    !logic_and: operation_expression
              | logic_and "&&" operation_expression -> binary_op
    operation_expression: unary_expr
                        | operation_expression binary_operator unary_expr -> binary_op
    unary_expr: unary | postfix
    !unary: UNARY_OP unary_expr -> unary_op
    !binary_operator: COMPARISON_OP | ARITHMETIC_OP | BITWISE_OP

    // Postfix chains
    postfix: primary
           | postfix "[" expression "]"                        -> array_access
           | postfix "(" (expression ("," expression)*)? ")"   -> function_call
           | postfix "." IDENT                                 -> dot_ident
           | postfix "->" IDENT                                -> arrow_ident
           | postfix "::" IDENT                                -> scope_ident

    // Atoms
    primary: predicate_call
           | wildcard
           | variable
           | literal
           | string_literal
           | "(" expression ")"  -> paren_expr

    // Predicates (capitalized names)
    pred_def: "PRED" PREDNAME "(" param_list? ")" ":=" expression -> pred_def
    param_list: IDENT ("," IDENT)*
    predicate_call: PREDNAME "(" (expression ("," expression)*)? ")" -> pred_call

    // ↑ Priority bump so uppercase identifiers are always tokenized as PREDNAME
    PREDNAME.9: /[A-Z][A-Za-z0-9_]*/
    IDENT.2:    /[A-Za-z][A-Za-z0-9_]*/

    // Wildcard
    wildcard: "_" -> wildcard

    // Components
    variable: IDENT
    literal: NUMBER | SIGNED_NUMBER | HEX_NUMBER | OCT_NUMBER | BIN_NUMBER
    !string_literal: /'.'/ | /".*?"/

    // Operators
    COMPARISON_OP: "==" | "!=" | "<" | ">" | "<=" | ">="
    ARITHMETIC_OP: "+" | "-" | "*" | "/" | "%" | "**"
    BITWISE_OP: "&" | "|" | "^" | "<<" | ">>"
    UNARY_OP: "!" | "-" | "~" | "++" | "--" | "*" | /(?<!&)&(?!&)/  // '&' is address-of

    // Separation-logic tokens
    SEP_CONJ.2: "⋆"
    MAPSTO.2: "↦" | "|->"

    HEX_NUMBER.2: /0x[\da-f]*(u)?/i
    OCT_NUMBER.2: /0o[0-7]*(u)?/i
    BIN_NUMBER.2 : /0b[0-1]*(u)?/i

    %import common.NUMBER
    %import common.SIGNED_NUMBER
    %import common.ESCAPED_STRING
    %import common.WS
    %ignore WS
"""


# ---------------------------
# SL result container
# ---------------------------
@dataclass
class _SLRes:
    expr: str
    addrs: List[str]
    is_wild: bool = False
    op: Optional[str] = None          # 'sep', 'mapsto', 'predcall'
    left: Optional['__class__'] = None
    right: Optional['__class__'] = None
    kind: str = "other"               # 'subobj' | 'deref' | 'addr' | 'call' | 'var' | 'other'
    is_addr: bool = False

# ---------------------------
# SL Transformer
# ---------------------------
class SEPTransformer(LarkTransformer):
    def __init__(self):
        super().__init__()
        self.preds: Dict[str, Tuple[List[str], object]] = {}
        self._def_order: List[str] = []

    # --- constructors/helpers ---
    def _R(self, expr, addrs=None, **kw):
        return _SLRes(expr=str(expr), addrs=list(addrs or []), **kw)

    def _as_res(self, x) -> _SLRes:
        if isinstance(x, _SLRes): return x
        if isinstance(x, Tree):   return self._as_res(self.transform(x))
        if isinstance(x, Token):  return self._R(x.value)
        return self._R(str(x))

    def _mk_sep(self, L: _SLRes, R: _SLRes) -> _SLRes:
        addrs = L.addrs + R.addrs
        disj = f"__sl_all_distinct({{ {', '.join(addrs)} }})" if addrs else "true"
        return self._R(f"({disj} && ({L.expr}) && ({R.expr}))", addrs, op="sep", left=L, right=R)

    def _pred_from_var(self, varR: _SLRes, args: List[_SLRes]) -> Optional[_SLRes]:
        name = varR.expr
        if not name or not name[0].isupper(): return None
        arg_str = ",".join(a.expr for a in args)
        addrs = sum((a.addrs for a in args), [])
        return self._R(f"__sl_pred_{name}({arg_str})", addrs, op="predcall")

    # --- SEPFORALL lowering (separating forall) ---
    def _mk_sforall(self, startR: _SLRes, endR: _SLRes, var: str, bodyR: _SLRes) -> _SLRes:
        """
        Lower: SEPFORALL(s, e, i, body(i))
        Semantics: conjunction of all body(i) with disjointness across iterations.
        """
        addrs = ", ".join(bodyR.addrs) if bodyR.addrs else ""
        lam = (
            "([&]{ "
            "std::unordered_set<const void*> __sl_cells; "
            "for(int " + var + " = " + startR.expr + "; " + var + " < " + endR.expr + "; ++" + var + ") { "
                "std::initializer_list<const void*> __sl_it_addrs{ " + addrs + " }; "
                "for(const void* __p : __sl_it_addrs) { "
                    "if (__p == nullptr || !__sl_cells.insert(__p).second) return false; "
                "} "
                "if (!(" + bodyR.expr + ")) return false; "
            "} "
            "return true; "
            "})()"
        )
        # Do not export dynamic addresses upward
        return self._R(lam, addrs=[])

    # --- SEPEXISTS lowering (separating exists) ---
    def _mk_sexists(self, startR: _SLRes, endR: _SLRes, var: str, bodyR: _SLRes) -> _SLRes:
        """
        Lower: SEPEXISTS(s, e, i, body(i))
        Semantics: there exists an index i in [s,e) such that body(i) holds.
        Note: We do not export dynamic addresses outward; separation inside 'body' is still enforced by ⋆.
        """
        lam = (
            "([&]{ "
            "for(int " + var + " = " + startR.expr + "; " + var + " < " + endR.expr + "; ++" + var + ") { "
                "if (" + bodyR.expr + ") return true; "
            "} "
            "return false; "
            "})()"
        )
        return self._R(lam, addrs=[])

    # --- top/start ---
    def start_expr(self, children):
        mainR = self._as_res(children[-1])
        decls = []
        for name in self._def_order:
            params, body_node = self.preds[name]
            bodyR = self._as_res(body_node)
            body_expr = bodyR.expr.replace(f"__sl_pred_{name}(", f"__sl_self_{name}(")
            lam = (
                f"auto __sl_pred_{name} = __sl_make_rec([&](auto __sl_self_{name}, "
                + ", ".join("auto " + p for p in params)
                + "){ return (" + body_expr + "); });"
            )
            decls.append(lam)
        if not decls:
            return mainR.expr
        preamble = " ".join(decls)
        return f"([&]{{ {preamble} return ({mainR.expr}); }})()"

    # --- predicate defs & calls ---
    def param_list(self, children):
        return [c.value for c in children if isinstance(c, Token)]

    def pred_def(self, children):
        name_tok = children[0]
        params = children[1] if len(children) == 3 and isinstance(children[1], list) else []
        body_node = children[-1]
        self.preds[name_tok.value] = (params, body_node)
        self._def_order.append(name_tok.value)
        return self._R("true")

    def pred_call(self, children):
        name = children[0].value
        args = [self._as_res(c) for c in children[1:]]
        # Quantifiers (uppercased names) supported here too
        if name in ("EXISTS", "FORALL") and len(args) == 4:
            startR, endR, varR, condR = args
            var = varR.expr
            if name == "EXISTS":
                lam = f"([&](){{ for(int {var} = {startR.expr}; {var} < {endR.expr}; ++{var}){{ if({condR.expr}) return true; }} return false; }})()"
            else:
                lam = f"([&](){{ for(int {var} = {startR.expr}; {var} < {endR.expr}; ++{var}){{ if(!({condR.expr})) return false; }} return true; }})()"
            return self._R(lam, condR.addrs)

        # NEW: SEPFORALL (predicate-style)
        if name == "SEPFORALL" and len(args) == 4:
            startR, endR, varR, bodyR = args
            return self._mk_sforall(startR, endR, varR.expr, bodyR)

        # NEW: SEPEXISTS (predicate-style)
        if name == "SEPEXISTS" and len(args) == 4:
            startR, endR, varR, bodyR = args
            return self._mk_sexists(startR, endR, varR.expr, bodyR)

        arg_str = ",".join(a.expr for a in args)
        return self._R(f"__sl_pred_{name}({arg_str})", sum((a.addrs for a in args), []), op="predcall")

    # --- expression wrappers ---
    def expression(self, children): return self._as_res(children[0]) if children else self._R("")
    def operation_expression(self, children): return self._as_res(children[0])
    def unary_expr(self, children): return self._as_res(children[0])
    def comp_expression(self, children): return self._as_res(children[0])

    # --- address helpers ---
    def _loc_pointer_expr(self, L: _SLRes) -> str:
        if L.is_addr: return L.expr
        if L.kind in ("subobj", "deref"): return f"&({L.expr})"
        return L.expr

    def _normalize_rhs_for_pointer_cell(self, L: _SLRes, R: _SLRes) -> str:
        # If L denotes a cell address and RHS is exactly *E, rewrite to E (so &*E ≡ E)
        if L.is_addr or (L.kind in ("subobj", "deref")):
            if R.kind == "deref" and R.left is not None:
                return R.left.expr
        return R.expr

    def _mapsto_core(self, L: _SLRes, R: _SLRes) -> _SLRes:
        loc_expr = self._loc_pointer_expr(L)
        if R.is_wild:
            addr = f"__sl_addr_of({loc_expr})"
            return self._R(f"__sl_mapsto_any({loc_expr})", addrs=[addr] + L.addrs, op="mapsto", left=L, right=R)
        rhs_expr = self._normalize_rhs_for_pointer_cell(L, R)
        addr = f"__sl_addr_of({loc_expr})"
        return self._R(f"__sl_mapsto({loc_expr}, {rhs_expr})", addrs=[addr] + L.addrs + R.addrs, op="mapsto", left=L, right=R)

    # --- SL operators ---
    def mapsto(self, children):
        L = self._as_res(children[0])
        R = self._as_res(children[2] if len(children) >= 3 else children[1])

        # Enforce precedence if RHS leaked a ⋆: pull it out
        def pull_star_right(lhs: _SLRes, rhs: _SLRes) -> _SLRes:
            if isinstance(rhs, _SLRes) and rhs.op == "sep" and rhs.left is not None and rhs.right is not None:
                left_map = pull_star_right(lhs, rhs.left)
                return self._mk_sep(left_map, rhs.right)
            return self._mapsto_core(lhs, rhs)

        return pull_star_right(L, R)

    def sep_conj(self, children):
        L = self._as_res(children[0])
        R = self._as_res(children[2] if len(children) >= 3 else children[1])
        return self._mk_sep(L, R)

    # --- logic & arithmetic ---
    def implication(self, children):
        L = self._as_res(children[0]); R = self._as_res(children[2] if len(children) >= 3 else children[1])
        return self._R(f"!({L.expr}) || ({R.expr})", L.addrs + R.addrs)

    def binary_operator(self, children):
        tok = children[0]
        return tok.value if isinstance(tok, Token) else str(tok)

    def binary_op(self, children):
        L = self._as_res(children[0])
        op_mid = children[1]
        op = op_mid.value if isinstance(op_mid, Token) else (op_mid if isinstance(op_mid, str) else str(op_mid))
        R = self._as_res(children[2])
        # Use runtime-aware equality to avoid pointer-vs-int UB and nullptr/0 conventions
        if op == "==": return self._R(f"__sl_eq({L.expr}, {R.expr})", L.addrs + R.addrs)
        if op == "!=": return self._R(f"__sl_ne({L.expr}, {R.expr})", L.addrs + R.addrs)
        return self._R(f"{L.expr} {op} {R.expr}", L.addrs + R.addrs)

    def unary_op(self, children):
        op_mid = children[0]
        op = op_mid.value if isinstance(op_mid, Token) else (op_mid if isinstance(op_mid, str) else str(op_mid))
        inner = self._as_res(children[1])
        if op == "&": return self._R(f"&({inner.expr})", inner.addrs, kind="addr", is_addr=True)
        if op == "*": return self._R(f"*{inner.expr}", inner.addrs, kind="deref", left=inner)
        return self._R(f"{op}{inner.expr}", inner.addrs)

    # --- postfix pieces ---
    def function_call(self, children):
        callee = self._as_res(children[0])
        args = [self._as_res(c) for c in children[1:]]

        # Quantifiers as function-calls too
        if callee.expr in ("EXISTS", "FORALL") and len(args) == 4:
            startR, endR, varR, condR = args
            var = varR.expr
            if callee.expr == "EXISTS":
                lam = f"([&](){{ for(int {var} = {startR.expr}; {var} < {endR.expr}; ++{var}){{ if({condR.expr}) return true; }} return false; }})()"
            else:
                lam = f"([&](){{ for(int {var} = {startR.expr}; {var} < {endR.expr}; ++{var}){{ if(!({condR.expr})) return false; }} return true; }})()"
            return self._R(lam, condR.addrs)

        # NEW: SEPFORALL as a function call
        if callee.expr == "SEPFORALL" and len(args) == 4:
            startR, endR, varR, bodyR = args
            return self._mk_sforall(startR, endR, varR.expr, bodyR)

        # NEW: SEPEXISTS as a function call
        if callee.expr == "SEPEXISTS" and len(args) == 4:
            startR, endR, varR, bodyR = args
            return self._mk_sexists(startR, endR, varR.expr, bodyR)

        # Structural fix: (L ⋆ P)(args)  ==>  L ⋆ P(args) (if P is a capitalized variable)
        if callee.op == "sep" and callee.right is not None:
            right = callee.right
            if right.kind == "var":
                predcall = self._pred_from_var(right, args)
                if predcall is not None:
                    return self._mk_sep(callee.left, predcall)

        arg_str = ",".join(a.expr for a in args)
        return self._R(f"{callee.expr}({arg_str})", callee.addrs + sum((a.addrs for a in args), []), kind="call")

    def array_access(self, children):
        A = self._as_res(children[0]); I = self._as_res(children[1])
        return self._R(f"{A.expr}[{I.expr}]", A.addrs + I.addrs, kind="subobj")

    def dot_ident(self, children):
        L = self._as_res(children[0]); name = children[1].value
        return self._R(f"{L.expr}.{name}", L.addrs, kind="subobj")

    def arrow_ident(self, children):
        L = self._as_res(children[0]); name = children[1].value
        return self._R(f"{L.expr}->{name}", L.addrs, kind="subobj")

    def scope_ident(self, children):
        L = self._as_res(children[0]); name = children[1].value
        return self._R(f"{L.expr}::{name}", L.addrs)

    # --- atoms/tokens ---
    def paren_expr(self, children):
        r = self._as_res(children[0])
        return self._R(f"({r.expr})", r.addrs, is_wild=r.is_wild, op=r.op,
                       left=r.left, right=r.right, kind=r.kind, is_addr=r.is_addr)

    def wildcard(self, _): return self._R("/*_*/", is_wild=True)
    def variable(self, children): return self._R(children[0].value, [], kind="var")
    def string_literal(self, children): return self._R(children[0].value)
    def literal(self, children): return self._R(children[0].value)

    def COMPARISON_OP(self, t): return t.value
    def ARITHMETIC_OP(self, t): return t.value
    def BITWISE_OP(self, t): return t.value
    def UNARY_OP(self, t): return t.value
    def MAPSTO(self, t): return t.value
    def SEP_CONJ(self, t): return t.value

    def __default__(self, data, children, meta):
        parts, addrs = [], []
        if len(children) == 1: return self._as_res(children[0])
        for c in children:
            rc = self._as_res(c); parts.append(rc.expr); addrs.extend(rc.addrs)
        return self._R(" ".join(parts), addrs)


# =========================================
# Unified entry point
# =========================================
def convert_postcondition_to_cpp(postcondition, logic: str = 'fol'):
    """Parse & translate `postcondition` to a single C++ boolean expression string.
       - logic='fol'  : use first-order logic grammar/transformer (no SL).
       - logic='sep'  : use separation-logic grammar/transformer (PRED/↦/⋆/_ + SEPFORALL/SEPEXISTS).
    Returns: (cpp_expr: str | None, error_message: str | None)
    """
    if logic == 'fol':
        grammar = fol_grammar
        parser = Lark(grammar, start='start', parser='earley')
        transformer = FOLTransformer()
    elif logic == 'sep':
        grammar = sep_grammar
        parser = Lark(grammar, start='start', parser='earley')
        transformer = SEPTransformer()
    else:
        msg = f"Unsupported logic '{logic}'. Use 'fol' or 'sep'."
        logger.info(msg)
        return None, msg

    try:
        parse_tree = parser.parse(postcondition)
        transformed_expr = transformer.transform(parse_tree)
    except Exception as e:
        error_msg = (
            f"Transformation of cpp {postcondition} postcondition failed!\nError\n{e}"
        )
        logger.info(error_msg)
        return None, error_msg + f"\nYour generated postcondition should follow the syntax of the grammar:\n{grammar}"

    return f"{transformed_expr}", None


# =========================================
# Precondition validation
# =========================================
class PreconditionValidator:
    """
    Validates that a precondition:
      1) Only references function parameter names (plus quantifier-bound vars / predicate params)
      2) Does NOT contain arbitrary *free* function calls like foo(x)
         - Allows quantifiers: FORALL/EXISTS/SEPFORALL/SEPEXISTS (by shape, not hardcoded methods)
         - Allows ANY method calls rooted in parameters/bound vars, e.g. arr.size(), s.substr(...), p->f()
         - Allows sep-logic predicate calls (PREDNAME(...)) as logical predicates (not C++ calls)
    """

    QUANTIFIERS: Set[str] = {"FORALL", "EXISTS", "SEPFORALL", "SEPEXISTS"}

    def __init__(
        self,
        param_names: List[str],
        logic: str = "fol",
    ):
        self.param_names = set(param_names)
        self.logic = logic

        self.invalid_identifiers: List[str] = []
        self.invalid_function_calls: List[str] = []

        # Bound variables from quantifiers, plus predicate parameters (sep)
        self._bound_vars_stack: List[Set[str]] = []

    # -----------------------
    # Scopes / binding
    # -----------------------
    def _is_bound(self, name: str) -> bool:
        return any(name in scope for scope in self._bound_vars_stack)

    def _push_scope(self, names: Set[str]) -> None:
        self._bound_vars_stack.append(set(names))

    def _pop_scope(self) -> None:
        if self._bound_vars_stack:
            self._bound_vars_stack.pop()

    # -----------------------
    # Helpers: tree shape
    # -----------------------
    def _is_member_access_node(self, t: Tree) -> bool:
        return t.data in {
            # fol
            "dot_expr", "arrow_expr", "scope_res",
            # sep
            "dot_ident", "arrow_ident", "scope_ident",
        }

    def _is_method_call(self, t: Tree) -> bool:
        if t.data != "function_call" or not t.children:
            return False
        callee = t.children[0]
        return isinstance(callee, Tree) and self._is_member_access_node(callee)

    def _extract_name_from_variable_node(self, node: Any) -> Optional[str]:
        # sep: Tree('variable',[Token('IDENT','x')])
        # fol: Tree('variable',[Token('CNAME','x')]) (typically)
        if isinstance(node, Tree) and node.data == "variable" and node.children:
            if isinstance(node.children[0], Token):
                return node.children[0].value
        if isinstance(node, Token) and node.type in ("CNAME", "IDENT"):
            return node.value
        return None

    def _callee_free_name(self, call_tree: Tree) -> Optional[str]:
        """If the callee is a bare name like foo(...), return 'foo'. Else None."""
        if call_tree.data != "function_call" or not call_tree.children:
            return None
        return self._extract_name_from_variable_node(call_tree.children[0])

    def _root_base_identifier(self, node: Any) -> Optional[str]:
        """
        For something like: arr[i].field->meth().x
        return the root identifier: 'arr'
        """
        if isinstance(node, Token):
            if node.type in ("CNAME", "IDENT"):
                return node.value
            return None

        if not isinstance(node, Tree) or not node.children:
            return None

        if node.data == "variable":
            return self._extract_name_from_variable_node(node)

        # peel wrappers / postfix-ish structures
        if node.data in ("paren_expr", "expression", "unary_expr", "operation_expression", "comp_expression"):
            return self._root_base_identifier(node.children[0])

        if node.data == "unary_op":
            # children: [op, inner] in sep transformer conventions; parse-tree is similar
            return self._root_base_identifier(node.children[-1])

        if node.data == "array_access":
            return self._root_base_identifier(node.children[0])

        if node.data == "function_call":
            # For chaining like obj.f().g(): root is still obj (from callee)
            return self._root_base_identifier(node.children[0])

        if self._is_member_access_node(node):
            # left . right ; root is in left
            return self._root_base_identifier(node.children[0])

        # fallback: try first child
        return self._root_base_identifier(node.children[0])

    def _is_quantifier_call_shape(self, name: str, argc: int) -> bool:
        # Your quantifiers are always 4-arg: (start, end, var, cond/body)
        return name in self.QUANTIFIERS and argc == 4

    def _collect_quantifier_bound_var(self, tree: Tree) -> Optional[str]:
        """
        Extract bound var name from:
          - fol: exists_expr / forall_expr
          - sep: pred_call(FORALL/EXISTS/...) or function_call(FORALL/EXISTS/...)
        """
        if tree.data in ("exists_expr", "forall_expr"):
            # children usually: [EXISTS/FORALL token, start, end, varToken, cond]
            # be robust: find the first Token that looks like an identifier in the expected slot(s)
            if len(tree.children) >= 4 and isinstance(tree.children[3], Token):
                return tree.children[3].value

        if tree.data == "pred_call":
            # children: [PREDNAME token, arg1, arg2, ...]
            if tree.children and isinstance(tree.children[0], Token):
                name = tree.children[0].value
                argc = len(tree.children) - 1
                if self._is_quantifier_call_shape(name, argc) and len(tree.children) >= 4:
                    var_arg = tree.children[3]
                    return self._extract_name_from_variable_node(var_arg)

        if tree.data == "function_call":
            free_name = self._callee_free_name(tree)
            argc = len(tree.children) - 1
            if free_name and self._is_quantifier_call_shape(free_name, argc) and len(tree.children) >= 4:
                var_arg = tree.children[3]
                return self._extract_name_from_variable_node(var_arg)

        return None

    def _collect_pred_def_params(self, pred_def_tree: Tree) -> Set[str]:
        """
        sep pred_def: "PRED" PREDNAME "(" param_list? ")" ":=" expression
        parse-tree children commonly: [PREDNAME token, param_list tree? , expression]
        """
        params: Set[str] = set()
        for ch in pred_def_tree.children:
            if isinstance(ch, Tree) and ch.data == "param_list":
                for tok in ch.children:
                    if isinstance(tok, Token) and tok.type == "IDENT":
                        params.add(tok.value)
        return params

    # -----------------------
    # Public entry
    # -----------------------
    def validate(self, tree) -> None:
        self._validate(tree, in_callee=False, in_member_name=False)

    # -----------------------
    # Core recursive walk
    # -----------------------
    def _validate(self, node, *, in_callee: bool, in_member_name: bool) -> None:
        # Token leaf
        if isinstance(node, Token):
            if in_callee or in_member_name:
                return
            if node.type in ("CNAME", "IDENT"):
                name = node.value
                if name not in self.param_names and not self._is_bound(name):
                    self.invalid_identifiers.append(name)
            return

        if not isinstance(node, Tree):
            return

        # Predicate definition (sep only): bind predicate params within body
        if node.data == "pred_def":
            # Record predicate name is *not* an identifier usage for precondition checking
            pred_params = self._collect_pred_def_params(node)
            if pred_params:
                self._push_scope(pred_params)
            try:
                # Body is typically last child
                if node.children:
                    self._validate(node.children[-1], in_callee=False, in_member_name=False)
            finally:
                if pred_params:
                    self._pop_scope()
            return

        # Quantifier nodes: bind var, but don't treat it as an identifier usage
        bound_var = self._collect_quantifier_bound_var(node)
        if bound_var:
            self._push_scope({bound_var})

        try:
            # Member access: validate only the left/receiver side; skip right "member name"
            if self._is_member_access_node(node):
                if node.children:
                    self._validate(node.children[0], in_callee=False, in_member_name=False)
                # right child is a name (Tree variable in fol, Token IDENT in sep); skip it
                return

            # Variable nodes (sep and usually fol)
            if node.data == "variable":
                name = self._extract_name_from_variable_node(node)
                if name and not in_callee and not in_member_name:
                    if name not in self.param_names and not self._is_bound(name):
                        self.invalid_identifiers.append(name)
                return

            # pred_call (sep): treat as logical predicate, not a C++ function call
            if node.data == "pred_call":
                # children[0] is PREDNAME token; skip it
                for arg in node.children[1:]:
                    self._validate(arg, in_callee=False, in_member_name=False)
                return

            # function_call: allow quantifiers and method calls rooted in params/bound vars
            if node.data == "function_call":
                callee = node.children[0] if node.children else None
                argc = max(0, len(node.children) - 1)

                # Determine if free call vs method call
                free_name = self._callee_free_name(node)
                is_method = self._is_method_call(node)

                allowed = False
                if free_name and self._is_quantifier_call_shape(free_name, argc):
                    allowed = True
                elif is_method:
                    root = self._root_base_identifier(callee)
                    if root and (root in self.param_names or self._is_bound(root)):
                        allowed = True

                if not allowed:
                    # Prefer a readable "name" if available
                    if free_name:
                        self.invalid_function_calls.append(free_name)
                    else:
                        # Non-trivial callee expression being called; report generic
                        self.invalid_function_calls.append("<indirect-call>")

                # Validate: for method call, validate callee receiver; for free call, skip callee name
                if is_method:
                    self._validate(callee, in_callee=False, in_member_name=False)
                else:
                    # don't count free function name as an "invalid identifier" too
                    if callee is not None:
                        self._validate(callee, in_callee=True, in_member_name=False)

                # Validate args
                for arg in node.children[1:]:
                    self._validate(arg, in_callee=False, in_member_name=False)
                return

            # Special-case fol quantifier nodes (exists_expr/forall_expr): skip bound-var token position
            if node.data in ("exists_expr", "forall_expr"):
                # Validate children except the bound var token itself (usually index 3)
                for i, ch in enumerate(node.children):
                    if i == 3:  # bound var
                        continue
                    # first child may be EXISTS/FORALL token
                    self._validate(ch, in_callee=False, in_member_name=False)
                return

            # Default: recurse into children
            for ch in node.children:
                self._validate(ch, in_callee=in_callee, in_member_name=in_member_name)

        finally:
            if bound_var:
                self._pop_scope()

    # -----------------------
    # Error reporting
    # -----------------------
    def get_error_message(self) -> Optional[str]:
        invalid_ids = sorted(set(self.invalid_identifiers))
        invalid_calls = sorted(set(self.invalid_function_calls))

        errors: List[str] = []
        if invalid_ids:
            errors.append(
                "The precondition contains identifiers that are not function parameters "
                f"(and not bound by quantifiers/predicate params): {invalid_ids}. "
                f"Allowed parameter names are: {sorted(self.param_names)}."
            )
        if invalid_calls:
            errors.append(
                "The precondition contains disallowed free function calls: "
                f"{invalid_calls}. "
                "Only quantifiers (FORALL/EXISTS/SEPFORALL/SEPEXISTS) and method calls "
                "rooted in parameters/bound vars are allowed by default."
            )
        return " ".join(errors) if errors else None


def validate_precondition(
    precondition: str,
    param_names: List[str],
    logic: str = 'fol'
) -> Optional[str]:
    """
    Validate that a precondition only uses function parameter names and contains no arbitrary function calls.
    
    This uses a parsing-based approach to analyze the precondition structure.
    
    Args:
        precondition: The precondition string to validate
        param_names: List of valid parameter names for the function
        logic: 'fol' or 'sep' - which grammar to use
    
    Returns:
        Error message if validation fails, None if validation passes
    """
    if precondition is None or not precondition.strip():
        return "Precondition is empty or None."
    
    # Select grammar based on logic type
    if logic == 'fol':
        grammar = fol_grammar
    elif logic == 'sep':
        grammar = sep_grammar
    else:
        return f"Unsupported logic '{logic}'. Use 'fol' or 'sep'."
    
    try:
        parser = Lark(grammar, start='start', parser='earley')
        parse_tree = parser.parse(precondition)
    except Exception as e:
        return f"Failed to parse precondition '{precondition}': {e}"
    
    # Validate the parse tree
    validator = PreconditionValidator(param_names, logic)
    validator.validate(parse_tree)
    
    return validator.get_error_message()
