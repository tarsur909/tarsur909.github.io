int* set_value(int* p, int v) {
    *p = v;
    return p;
}
