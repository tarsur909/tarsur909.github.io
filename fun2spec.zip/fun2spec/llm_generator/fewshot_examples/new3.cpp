int safe_divide(int a, int b)
// Given integers a and b, return a/b when b != 0; if b == 0, return 0 to avoid division by zero
{
    if (b == 0) return 0;
    return a / b;
}
