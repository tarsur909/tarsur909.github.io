int* init_indices(int* a, int n) {
    for (int i = 0; i < n; ++i) {
        a[i] = i;
    }
    return a;
}
