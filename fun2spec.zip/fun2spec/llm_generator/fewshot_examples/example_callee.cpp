int g(int x) {
    return x * 2;  
}

int f(int v) {
    int local = g(v);
    return local;
}