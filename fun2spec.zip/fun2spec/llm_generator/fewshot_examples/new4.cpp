int max_element(const vector<int>& v)
// Given a non-empty vector v, return the maximum element contained in v
{
    int n = v.size(), mx = v[0];
    for (int i = 1; i < n; ++i)
        if (v[i] > mx) mx = v[i];
    return mx;
}
