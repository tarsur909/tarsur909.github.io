#include <string>

struct NameVal {
    std::string f1;
    std::string f2;
};

class A {
    NameVal d_i;
public:
    void set(const std::string& val1, const std::string& val2) {
        d_i.f1 = val1;
        d_i.f2 = val2;
    }
};
