// Add value to front for a singly-linked list
struct Node {{
    int val;
    Node* next;
    explicit Node(int v): val(v), next(nullptr) {{}}
}};

Node* push_front(Node* head, int v) {{
    Node* r = new Node(v);
    r->next = head;
    return r;
}}
