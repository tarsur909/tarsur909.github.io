#include <set>
#include <string>
#include <iterator>

struct Student {{
    int id;
    int score;
    std::string name;
    Student(int i, int s, std::string n): id(i), score(s), name(std::move(n)) {{}}
}};

struct ByScoreThenId {{
    bool operator()(Student const& a, Student const& b) const {{
        if (a.score != b.score) return a.score < b.score;
        return a.id < b.id;
    }}
}};

// Returns a heap-allocated copy of the max by (score,id), or nullptr if empty
Student* copy_top(std::set<Student, ByScoreThenId> const& S) {{
    if (S.empty()) return nullptr;
    const Student& top = *std::prev(S.end());
    return new Student(top.id, top.score, top.name);
}}
