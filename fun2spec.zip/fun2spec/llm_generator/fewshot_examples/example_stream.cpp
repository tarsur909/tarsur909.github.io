#include <ostream>

void f(std::ostream& s, const char* v) {
    if (v == nullptr) {
        return; 
    }
    s << v;
}
