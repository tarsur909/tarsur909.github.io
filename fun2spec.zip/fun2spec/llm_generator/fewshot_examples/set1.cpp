#include <string>

class A {
    std::string d_name;
    std::string d_val;
public:
    void set(const std::string& val1, const std::string& val2) {
        d_name = val1;
        d_val  = val2;
    }
};
