bool between(int a, int b, int c)
// Given integers a, b, c, return true if and only if b lies between a and c (inclusive) in either order
{
    return (a <= b && b <= c) || (c <= b && b <= a);
}
