int clamp(int x, int lo, int hi)
// Given an integer x and bounds lo, hi, return x clamped into the inclusive range [lo, hi]
{
    if (x < lo)   return lo;
    if (x > hi)   return hi;
                  return x;
}
