
bool has_zero(const int* a, int n) {
    for (int i = 0; i < n; ++i) {
        if (a[i] == 0) return true;
    }
    return false;
}
