#include <string>

struct NameVal {
    std::string f1;
    std::string f2;
};

class A {
    NameVal* d_j{nullptr};
public:
    ~A() { delete d_j; }

    void set(const std::string& val1, const std::string& val2) {
        delete d_j;
        d_j = new NameVal{val1, val2};
    }
};
