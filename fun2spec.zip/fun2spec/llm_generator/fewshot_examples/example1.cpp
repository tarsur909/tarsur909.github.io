int add_invert(const int x)
// Given a positive number return the its additive negation
{
    return -x;
}
