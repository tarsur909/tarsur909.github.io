
"""
This file stores the tempalte for prompts used for LLM generation.
"""
import jinja2
import jsonlines, os
import common
from function_data import FunctionData
from code_miner.ts_parser import get_ts_fn_node_docstring, get_all_ts_function_nodes, detect_quantifier_implies
from code_miner.clang_parser import get_all_functions_clang
import yaml

# Instructtion
post_prompt_instruction = """As an expert language model trained in understanding code, your task is to generate a postcondition (POST) for the provided C++ function.
A postcondition is a predicate wrapped in POST(any_predicate) that represents a condition guaranteed to be true after the function returns.
Follow these rules to construct the postcondition:

1. Syntax: Wrap the postcondition in POST(any_predicate).
2. Implications: Use the symbol “==>” for logical implication. For example, condition1 ==> condition2 indicates that if condition1 is true, then condition2 must also be true.
3. Logical Operators: You may use “&&” (logical AND) and “||” (logical OR) to combine multiple conditions within a single predicate. condition1 && condition2 indicates that both conditions must be true. condition1 || condition2 indicates that at least one of the conditions is true.
4. All predicates used in postcondition should be valid C++ expressions. All predicates will be executed using C++ compiler.
5. Valid Function Names: All function/method calls used in the predicate should exist in the context of the function. Do not hallucinate use and any hypothetical function name!
6. Naming the Return Value: Use "res_tmp" as the name of the return value.
7. Trivial Postcondition: If no specific predicates must hold for the function, return a trivial postcondition, POST(true).
8. Single Postcondition: Return only one postcondition per function.
9. Always include the appropriate namespace in postconditions if the constant, type, or function is qualified with a namespace in the code. If no namespace is used in the code, refer to the constant or type directly without a namespace in the postcondition.
"""

# Instructtion with quantifiers
post_prompt_instruction_quantifiers = """As an expert language model trained in understanding code, your task is to generate a postcondition (POST) for the provided C++ function.
A postcondition is a predicate wrapped in POST(any_predicate) that represents a condition guaranteed to be true after the function returns.
Follow these rules to construct the postcondition:

1. Syntax: Wrap the postcondition in POST(any_predicate).
2. Implications: Use the symbol "==>" for logical implication. For example, condition1 ==> condition2 indicates that if condition1 is true, then condition2 must also be true.
3. Logical Operators: You may use "&&" (logical AND) and "||" (logical OR) to combine multiple conditions within a single predicate. condition1 && condition2 indicates that both conditions must be true. condition1 || condition2 indicates that at least one of the conditions is true.
4. Quantifiers: You may use EXISTS and FORALL to express quantified conditions:
   - EXISTS(start, end, var, condition): There exists a value var in range [start, end) that satisfies condition
   - FORALL(start, end, var, condition): All values var in range [start, end) satisfy condition

   Example: POST(res_tmp == true ==> EXISTS(0, numbers.size(), i, numbers[i] == target))
5. All predicates used in postcondition should be valid C++ expressions. All predicates will be executed using C++ compiler.
6. Valid Function Names: All function/method calls used in the predicate should exist in the context of the function. Do not hallucinate use and any hypothetical function name! Instead give a simpler postcondition.
7. Naming the Return Value: Use "res_tmp" as the name of the return value.
8. Trivial Postcondition: If no specific predicates must hold for the function, return a trivial postcondition, POST(true).
9. Single Postcondition: Return only one postcondition per function.
10. Always include the appropriate namespace in postconditions if the constant, type, or function is qualified with a namespace in the code. If no namespace is used in the code, refer to the constant or type directly without a namespace in the postcondition.
"""

# This is taken from https://arxiv.org/pdf/2310.01831
post_prompt_instruction_nl2post = """Write a symbolic postcondition for {} consisting of exactly one postcondition statement
wrapped in POST(assertion). For variables, use only the function input parameters and a hypothetical
return value, which we will assume to be stored in variable "res_tmp". If the postcondition calls any
functions to external to the program context they should be only be those from the functional subsets
of C++. By this, we mean functions that are pure (i.e., no side effects) such as:
"""

def build_prompt(
        target_fn_data: FunctionData,
        tokenizer,
        few_shot=4,
        add_doc=False,
        add_cot=True,
        add_ret_type=True,
        quantifier_prompt=True,
        prev_result=None,
        nl2post=False,
        strongest_post_prompt = False,
        logic = 'fol'
        ) -> str:
    """
    Takes the examples from examples.jsonl file and builds the prompt.
    """

    # Build few shot examples
    examples_dir = os.path.dirname(os.path.realpath(__file__))+'/fewshot_examples/'
    with open(os.path.dirname(os.path.realpath(__file__))+'/prompt_template.yaml', 'r') as f:
        prompt_template = yaml.safe_load(f)

    # Load the example list from the jsonlines file
    if logic == 'fol':
        with jsonlines.open(examples_dir+'example_list.jsonl', 'r') as jsonl_f:
            examples = [obj for obj in jsonl_f]

        # Use first `few_shot` examples from the json
        examples = examples[:few_shot]

    elif logic == 'sep':
        with jsonlines.open(examples_dir+'example_sep_list.jsonl', 'r') as jsonl_f:
            examples = [obj for obj in jsonl_f]

    fs_examples = []

    for i in range(len(examples)):
        fs_example, fs_out = build_fewshot_example(add_doc, add_cot, add_ret_type, examples_dir, examples, i)
        fs_examples.append((fs_example, fs_out))


    if not nl2post:
        instruction = prompt_template['main']['general_instruction']
        constructs = detect_quantifier_implies(target_fn_data.function_string)
        rules = ['syntax', 'implications', 'logical_operators', 'quantifiers', 'separation_conjunction', 'mapsto', 'separation_logic', 'fol_sep', 'valid_cpp', 'valid_funcs', 'return_name', 'old_var', 'trivial_post', 'single_post','namespace']
        if not quantifier_prompt or 'quantifier' not in constructs:
            rules.remove('quantifiers')
            rules.remove('fol_sep')

        if logic != 'sep':
            rules.remove('separation_conjunction')
            rules.remove('mapsto')
            rules.remove('separation_logic')
            if 'fol_sep' in rules:
                rules.remove('fol_sep')

        for i, rule in enumerate(rules):
            instruction += f"\n{i + 1}. {prompt_template['main']['rules'][rule]}"
        instruction += "\n"

        # Build input
        inp = build_input(target_fn_data, add_doc, add_ret_type)
        prompt = ""

        for i in range(len(examples)):
            # msg.append({"role": "user", "content": fs_examples[i][0]})
            # msg.append({"role": "assistant", "content": fs_examples[i][1]})

            # NOTE: The following method of adding all examples in on msg worked better
            #  than creating the whole conversation
            prompt += fs_examples[i][0] + fs_examples[i][1]

        full_prompt = prompt + inp

        if prev_result is not None:
            rep = "Your previous response:\n"
            if 'postcondition' in prev_result:
                rep += f"Postcondition:\n{prev_result['postcondition']}\n"
            else:
                rep += f"{prev_result['raw_gen']}\n"
            if prev_result['result'] == 'Compilation error':
                rep += f"Error Type:\n{prev_result['result']}\n"
            elif prev_result['result'] == False:
                rep += f"Error Type:\nIncorrect Postcondition\n"

            # If the error log is too long (more than 10 lines)
            # Extract lines that have error string in it
            if prev_result['result'] == 'Compilation error':
                error_summary = extract_error_lines(prev_result['error_msg'])
            else:
                error_summary = prev_result['error_msg']

            rep += f"Error log:{error_summary}\n\n"
            rep += f"Your previous generation was buggy. Can you fix that error and generate a new postcondition?"
            full_prompt += rep
    else:
        # This is for nl2post prompt from the paper
        # "Can LLMs Transform NL Intent into Formal Method Postconditions? FSE’24"
        # https://arxiv.org/pdf/2310.01831

        instruction = prompt_template['nl2post']['system_instruction'].replace("FUNC_NAME", target_fn_data.function_name)

        prompt = target_fn_data.function_string + prompt_template['nl2post']['prompt_prefix'].format(target_fn_data.function_name)

        for i in range(len(examples)):
            prompt += fs_examples[i][0] + fs_examples[i][1]

    # Apply chat template according to the tokenizer of the corresponding model
    if tokenizer is None:
        msg = [{"role": "system", "content": instruction}]
        msg.append({"role": "user", "content": full_prompt})
        chat_prompt = msg
    else:
        if 'apply_chat_template' in dir(tokenizer):
            try:
                msg = [{"role": "system", "content": instruction}]
                msg.append({"role": "user", "content": full_prompt})
                chat_prompt = tokenizer.apply_chat_template(
                    msg,
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=False
                    )
            except jinja2.exceptions.TemplateError:
                # Some models do not support "system" message e.g. google/gemma-2-9b-it
                msg = [{"role": "user", "content": instruction+"\n"+full_prompt}]
                chat_prompt = tokenizer.apply_chat_template(
                    msg,
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=False
                    )
        else:
            raise ValueError("Not supported!")
    return chat_prompt

def build_input(target_fn_data, add_doc, add_ret_type):
    inp = f"Function:\n{target_fn_data.function_string}\n"

    if add_ret_type:
        rtype = target_fn_data.return_type.name
        inp += f"Return Type: {rtype}\n"
        inp += f"Arguments used for postcondition: res_tmp, {', '.join(target_fn_data.args)}\n"

    if add_doc:
        inp += f"Documentation:\n{target_fn_data.docstring}\n"
    return inp

def build_fewshot_example(add_doc, add_cot, add_ret_type, examples_dir, examples, i):
    fname = examples_dir+examples[i]['code_path']
    fnode = get_all_ts_function_nodes(fname)[0]
    docstring = get_ts_fn_node_docstring(fnode)
    fs_example = ""

    function_str = ''.join(common.get_file_lines(fname))

    # Create the part of the prompt with current example
    # prompt += f"\n------ Example {i+1}\n"

    # Add the function definition in the prompt
    fs_example += f"Function:\n{function_str}\n"

    cnode = get_all_functions_clang(fname)[-1]

    if add_ret_type:
        rtype = cnode.result_type.get_canonical().spelling
        fs_example += f"Return Type: {rtype}\n"
        fs_example += f"Arguments used for postcondition: res_tmp, {', '.join([arg.spelling for arg in cnode.get_arguments()])}\n"

    if add_doc: # Add documentation in the prompt
        fs_example += f"Documentation:\n{docstring}\n"

    fs_out = ""
    if add_cot:
        fs_out += f"Reasoning:\nLet's think about this step by step. {examples[i]['reasoning']}\n"

    fs_out += f"Postcondition:\n{examples[i]['post']}\n"
    return fs_example,fs_out

def build_precondition_prompt(
        target_fn_data: FunctionData,
        postcondition_str: str,
        tokenizer,
        add_cot=True,
        prev_result=None,
        logic='fol',
        few_shot=4
        ) -> str:
    """
    Builds a prompt for generating a precondition given function body and postcondition.
    Uses the YAML template structure for consistency with postcondition prompts.
    Includes few-shot examples for better precondition generation.
    """
    # Load prompt template from YAML
    with open(os.path.dirname(os.path.realpath(__file__))+'/prompt_template.yaml', 'r') as f:
        prompt_template = yaml.safe_load(f)
    
    # Build instruction from template
    instruction = prompt_template['precondition']['general_instruction']
    
    # Add rules - include separation logic rules for sep logic mode
    rules = ['syntax', 'weakest', 'implications', 'logical_operators', 'quantifiers', 
             'valid_cpp', 'valid_funcs', 'input_vars', 'trivial_pre', 'single_pre', 'namespace']
    
    # Add separation logic rules if in sep logic mode
    if logic == 'sep':
        # Insert sep logic rules after quantifiers
        rules = ['syntax', 'weakest', 'implications', 'logical_operators', 'quantifiers',
                 'separation_conjunction', 'mapsto', 'separation_logic', 'fol_sep',
                 'valid_cpp', 'valid_funcs', 'input_vars', 'trivial_pre', 'single_pre', 'namespace']
    
    for i, rule in enumerate(rules):
        instruction += f"\n{i + 1}. {prompt_template['precondition']['rules'][rule]}"
    instruction += "\n"
    
    # Build few-shot examples
    prompt = ""
    if few_shot > 0:
        examples_dir = os.path.dirname(os.path.realpath(__file__))+'/fewshot_examples/'
        
        # Load the example list from the jsonlines file based on logic type
        if logic == 'fol':
            with jsonlines.open(examples_dir+'example_list.jsonl', 'r') as jsonl_f:
                examples = [obj for obj in jsonl_f]
            
            # Use first `few_shot` examples from the json
            examples = examples[:few_shot]
        
        elif logic == 'sep':
            with jsonlines.open(examples_dir+'example_sep_list.jsonl', 'r') as jsonl_f:
                examples = [obj for obj in jsonl_f]
            
            # Use first `few_shot` examples from the json
            examples = examples[:few_shot]
        
        for i in range(len(examples)):
            fs_example, fs_out = build_precondition_fewshot_example(add_cot, examples_dir, examples, i)
            prompt += fs_example + fs_out
    
    # Build input for target function
    inp = f"Function:\n{target_fn_data.function_string}\n"
    inp += f"Postcondition:\n{postcondition_str}\n"
    inp += f"Arguments that can be used in precondition: {', '.join(target_fn_data.args)}\n"
    
    if prev_result is not None:
        rep = "Your previous response:\n"
        if 'precondition' in prev_result:
            rep += f"Precondition:\n{prev_result['precondition']}\n"
        else:
            rep += f"{prev_result.get('raw_gen_pre', '')}\n"
        
        if prev_result.get('pre_result') == 'Compilation error':
            rep += f"Error Type:\n{prev_result['pre_result']}\n"
        elif prev_result.get('pre_result') == False:
            rep += f"Error Type:\nIncorrect Precondition\n"
        
        # Extract error lines if error log is too long
        if prev_result.get('pre_result') == 'Compilation error':
            error_summary = extract_error_lines(prev_result.get('pre_error_msg', ''))
        else:
            error_summary = prev_result.get('pre_error_msg', '')
        
        rep += f"Error log:{error_summary}\n\n"
        rep += f"Your previous generation was buggy. Can you fix that error and generate a new precondition?"
        inp += rep
    
    full_prompt = prompt + inp
    
    # Apply chat template according to the tokenizer
    if tokenizer is None:
        msg = [{"role": "system", "content": instruction}]
        msg.append({"role": "user", "content": full_prompt})
        chat_prompt = msg
    else:
        if 'apply_chat_template' in dir(tokenizer):
            try:
                msg = [{"role": "system", "content": instruction}]
                msg.append({"role": "user", "content": full_prompt})
                chat_prompt = tokenizer.apply_chat_template(
                    msg,
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=False
                    )
            except jinja2.exceptions.TemplateError:
                # Some models do not support "system" message
                msg = [{"role": "user", "content": instruction+"\n"+full_prompt}]
                chat_prompt = tokenizer.apply_chat_template(
                    msg,
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=False
                    )
        else:
            raise ValueError("Not supported!")
    return chat_prompt

def build_precondition_fewshot_example(add_cot, examples_dir, examples, i):
    """
    Builds a few-shot example for precondition generation.
    """
    fname = examples_dir + examples[i]['code_path']
    function_str = ''.join(common.get_file_lines(fname))
    
    fs_example = f"Function:\n{function_str}\n"
    fs_example += f"Postcondition:\n{examples[i]['post']}\n"
    
    # Get arguments from the function
    cnode = get_all_functions_clang(fname)[-1]
    args = [arg.spelling for arg in cnode.get_arguments()]
    fs_example += f"Arguments that can be used in precondition: {', '.join(args)}\n"
    
    fs_out = ""
    if add_cot and 'pre_reasoning' in examples[i]:
        fs_out += f"Reasoning:\nLet's think about this step by step. {examples[i]['pre_reasoning']}\n"
    
    fs_out += f"Precondition:\n{examples[i]['pre']}\n"
    return fs_example, fs_out

def extract_error_lines(text, max_lines=10):
    # Split the text into lines
    all_lines = text.splitlines()

    # If the entire text has fewer than 10 lines, return all lines
    if len(all_lines) <= max_lines:
        return text

    # Otherwise, extract lines containing "error" (case-insensitive)
    error_lines = [line for line in all_lines if "error" in line.lower()]

    # If there are more than max_lines error lines, return only the bottom max_lines
    if len(error_lines) > max_lines:
        error_lines = error_lines[-max_lines:]

    # Join the selected lines with newlines and return as a string
    return '\n'.join(error_lines)
