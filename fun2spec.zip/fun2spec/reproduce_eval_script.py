# Script to run all experiments
from main import run

def run_exp(reasoning_models, all_models, return_types, add_docs, add_cot, few_shots, use_quantifiers, reprompt, sources, timeout, count):
    for source in sources:
        for model, cached_path in all_models:
            for few_shot in few_shots:
                for return_type in return_types:
                    for add_doc in add_docs:
                        if source == "humaneval":
                            add_ret_type = False
                        else:
                            add_ret_type = True


                        if model in reasoning_models:
                            max_new_tokens = 800
                        else:
                            max_new_tokens = 400

                        try:
                            run(
                            source=source,
                            model_name=model,
                            return_type=return_type,
                            use_cache=True,
                            count=count,
                            timeout=timeout,
                            add_doc=add_doc,
                            add_cot=add_cot,
                            few_shot=few_shot,
                            add_ret_type=add_ret_type,
                            use_quantifiers=use_quantifiers,
                            total_attempts = 12, logic = 'sep',
                            max_new_tokens=max_new_tokens,
                            run_parallel = True,
                            num_parallel_workers = 48,
                            gen_backend = 'sglang',
                            cached_model_path = cached_path

                            )
                        except Exception as e:
                            raise e

def main():
    models = [
    #("Qwen/Qwen2.5-Coder-7B-Instruct", '/home/tarun/cache-julien-with-Qwen32-instr/huggingface/hub/models--Qwen--Qwen2.5-Coder-7B-Instruct/snapshots/c03e6d358207e414f1eca0bb1891e29f1db0e242'),
    ("Qwen/Qwen2.5-32B-Instruct", '/home/tarun/cache-julien-with-Qwen32-instr/huggingface/hub/models--Qwen--Qwen2.5-32B-Instruct/snapshots/5ede1c97bbab6ce5cda5812749b4c0bdf79b18dd')]
    #('microsoft/phi-4', '/home/tarun/cache-julien-with-Qwen32-instr/huggingface/hub/models--microsoft--phi-4/snapshots/187ef0342fff0eb3333be9f00389385e95ef0b61')]
    #('Qwen/QwQ-32B', '/home/tarun/cache-julien-with-Qwen32-instr/huggingface/hub/models--Qwen--QwQ-32B/snapshots/976055f8c83f394f35dbd3ab09a285a984907bd0'),
    #('microsoft/Phi-4-mini-instruct','/home/tarun/cache-julien-with-Qwen32-instr/huggingface/hub/models--microsoft--Phi-4-mini-instruct/snapshots/5a149550068a1eb93398160d8953f5f56c3603e9')

    #]

    reasoning_models = [
    ]

    all_models = models + reasoning_models

    # return_types = ['int', 'all']
    return_types = ['all']
    add_docs = [False]
    add_cot = True
    few_shots = [4]
    use_quantifiers = True
    reprompt = True

    # source = "humaneval"
    # source = "analysis_code/bde"
    sources = ["analysis_code/blazingmq"]
    #sources = ["humaneval", "analysis_code/bde", "analysis_code/blazingmq"]

    timeout = 60
    count = 2000
    run_exp(
        reasoning_models,
        all_models,
        return_types,
        add_docs,
        add_cot,
        few_shots,
        use_quantifiers,
        reprompt,
        sources,
        timeout,
        count
        )

if __name__ == "__main__":
    main()
